(kicadstamp-config)
