(kicadstamp-config
  (root_sheet "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103/3CH-AWG-TIA-v103.kicad_sch")
  (schematic_dir "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103")
  (schematic_files "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103/channel.kicad_sch")
  (trees
    (tree
      (name "ch0_dac_buf")
    )
  )
)
