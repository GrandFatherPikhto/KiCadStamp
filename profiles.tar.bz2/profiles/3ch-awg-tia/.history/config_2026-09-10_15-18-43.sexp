(kicadstamp-config
  (root_sheet "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103/3CH-AWG-TIA-v103.kicad_sch")
  (schematic_dir "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103")
  (schematic_files "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v103/channel.kicad_sch")
  (trees
    (tree
      (name "ch0_dac_buf")
      (anchor
        (role "AD_DAC")
        (sheet "Channel_0")
        (cluster "DAC_BUF")
      )
      (node
        (ref "pif_oa_n2v5_channel_0")
        (kind placement)
        (xy 50.0 -2.0)
        (anchor
          (role "OP_AMP")
          (sheet "Channel_0")
          (cluster "DAC_BUF")
          (pad "4")
        )
      )
    )
  )
  (cells)
  (entities)
)
