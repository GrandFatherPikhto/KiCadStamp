(kicadstamp-config
  (layer "B.Cu")
  (cells
    (cell
      "cell_0"
      (components
        (component
          (role "R0_0")
        )
        (component
          (role "R0_1")
        )
      )
    )
    (cell
      "cell_1"
      (components
        (component
          (role "R1_0")
        )
        (component
          (role "R1_1")
        )
      )
    )
    (cell
      "cell_2"
      (components
        (component
          (role "R2_0")
        )
        (component
          (role "R2_1")
        )
      )
    )
    (cell
      "cell_3"
      (components
        (component
          (role "R3_0")
        )
        (component
          (role "R3_1")
        )
      )
    )
    (cell
      "cell_4"
      (components
        (component
          (role "R4_0")
        )
        (component
          (role "R4_1")
        )
      )
    )
    (cell
      "cell_5"
      (components
        (component
          (role "R5_0")
        )
        (component
          (role "R5_1")
        )
      )
    )
    (cell
      "cell_6"
      (components
        (component
          (role "R6_0")
        )
        (component
          (role "R6_1")
        )
      )
    )
    (cell
      "cell_7"
      (components
        (component
          (role "R7_0")
        )
        (component
          (role "R7_1")
        )
      )
    )
    (cell
      "cell_8"
      (components
        (component
          (role "R8_0")
        )
        (component
          (role "R8_1")
        )
      )
    )
    (cell
      "cell_9"
      (components
        (component
          (role "R9_0")
        )
        (component
          (role "R9_1")
        )
      )
    )
    (cell
      "cell_10"
      (components
        (component
          (role "R10_0")
        )
        (component
          (role "R10_1")
        )
      )
    )
    (cell
      "cell_11"
      (components
        (component
          (role "R11_0")
        )
        (component
          (role "R11_1")
        )
      )
    )
    (cell
      "cell_12"
      (components
        (component
          (role "R12_0")
        )
        (component
          (role "R12_1")
        )
      )
    )
    (cell
      "cell_13"
      (components
        (component
          (role "R13_0")
        )
        (component
          (role "R13_1")
        )
      )
    )
    (cell
      "cell_14"
      (components
        (component
          (role "R14_0")
        )
        (component
          (role "R14_1")
        )
      )
    )
    (cell
      "cell_15"
      (components
        (component
          (role "R15_0")
        )
        (component
          (role "R15_1")
        )
      )
    )
    (cell
      "cell_16"
      (components
        (component
          (role "R16_0")
        )
        (component
          (role "R16_1")
        )
      )
    )
    (cell
      "cell_17"
      (components
        (component
          (role "R17_0")
        )
        (component
          (role "R17_1")
        )
      )
    )
    (cell
      "cell_18"
      (components
        (component
          (role "R18_0")
        )
        (component
          (role "R18_1")
        )
      )
    )
    (cell
      "cell_19"
      (components
        (component
          (role "R19_0")
        )
        (component
          (role "R19_1")
        )
      )
    )
    (cell
      "cell_20"
      (components
        (component
          (role "R20_0")
        )
        (component
          (role "R20_1")
        )
      )
    )
    (cell
      "cell_21"
      (components
        (component
          (role "R21_0")
        )
        (component
          (role "R21_1")
        )
      )
    )
    (cell
      "cell_22"
      (components
        (component
          (role "R22_0")
        )
        (component
          (role "R22_1")
        )
      )
    )
    (cell
      "cell_23"
      (components
        (component
          (role "R23_0")
        )
        (component
          (role "R23_1")
        )
      )
    )
    (cell
      "cell_24"
      (components
        (component
          (role "R24_0")
        )
        (component
          (role "R24_1")
        )
      )
    )
    (cell
      "cell_25"
      (components
        (component
          (role "R25_0")
        )
        (component
          (role "R25_1")
        )
      )
    )
    (cell
      "cell_26"
      (components
        (component
          (role "R26_0")
        )
        (component
          (role "R26_1")
        )
      )
    )
    (cell
      "cell_27"
      (components
        (component
          (role "R27_0")
        )
        (component
          (role "R27_1")
        )
      )
    )
    (cell
      "cell_28"
      (components
        (component
          (role "R28_0")
        )
        (component
          (role "R28_1")
        )
      )
    )
    (cell
      "cell_29"
      (components
        (component
          (role "R29_0")
        )
        (component
          (role "R29_1")
        )
      )
    )
    (cell
      "cell_30"
      (components
        (component
          (role "R30_0")
        )
        (component
          (role "R30_1")
        )
      )
    )
    (cell
      "cell_31"
      (components
        (component
          (role "R31_0")
        )
        (component
          (role "R31_1")
        )
      )
    )
    (cell
      "cell_32"
      (components
        (component
          (role "R32_0")
        )
        (component
          (role "R32_1")
        )
      )
    )
    (cell
      "cell_33"
      (components
        (component
          (role "R33_0")
        )
        (component
          (role "R33_1")
        )
      )
    )
    (cell
      "cell_34"
      (components
        (component
          (role "R34_0")
        )
        (component
          (role "R34_1")
        )
      )
    )
    (cell
      "cell_35"
      (components
        (component
          (role "R35_0")
        )
        (component
          (role "R35_1")
        )
      )
    )
    (cell
      "cell_36"
      (components
        (component
          (role "R36_0")
        )
        (component
          (role "R36_1")
        )
      )
    )
    (cell
      "cell_37"
      (components
        (component
          (role "R37_0")
        )
        (component
          (role "R37_1")
        )
      )
    )
    (cell
      "cell_38"
      (components
        (component
          (role "R38_0")
        )
        (component
          (role "R38_1")
        )
      )
    )
    (cell
      "cell_39"
      (components
        (component
          (role "R39_0")
        )
        (component
          (role "R39_1")
        )
      )
    )
    (cell
      "cell_40"
      (components
        (component
          (role "R40_0")
        )
        (component
          (role "R40_1")
        )
      )
    )
    (cell
      "cell_41"
      (components
        (component
          (role "R41_0")
        )
        (component
          (role "R41_1")
        )
      )
    )
    (cell
      "cell_42"
      (components
        (component
          (role "R42_0")
        )
        (component
          (role "R42_1")
        )
      )
    )
    (cell
      "cell_43"
      (components
        (component
          (role "R43_0")
        )
        (component
          (role "R43_1")
        )
      )
    )
    (cell
      "cell_44"
      (components
        (component
          (role "R44_0")
        )
        (component
          (role "R44_1")
        )
      )
    )
    (cell
      "cell_45"
      (components
        (component
          (role "R45_0")
        )
        (component
          (role "R45_1")
        )
      )
    )
    (cell
      "cell_46"
      (components
        (component
          (role "R46_0")
        )
        (component
          (role "R46_1")
        )
      )
    )
    (cell
      "cell_47"
      (components
        (component
          (role "R47_0")
        )
        (component
          (role "R47_1")
        )
      )
    )
    (cell
      "cell_48"
      (components
        (component
          (role "R48_0")
        )
        (component
          (role "R48_1")
        )
      )
    )
    (cell
      "cell_49"
      (components
        (component
          (role "R49_0")
        )
        (component
          (role "R49_1")
        )
      )
    )
    (cell
      "cell_50"
      (components
        (component
          (role "R50_0")
        )
        (component
          (role "R50_1")
        )
      )
    )
    (cell
      "cell_51"
      (components
        (component
          (role "R51_0")
        )
        (component
          (role "R51_1")
        )
      )
    )
    (cell
      "cell_52"
      (components
        (component
          (role "R52_0")
        )
        (component
          (role "R52_1")
        )
      )
    )
    (cell
      "cell_53"
      (components
        (component
          (role "R53_0")
        )
        (component
          (role "R53_1")
        )
      )
    )
    (cell
      "cell_54"
      (components
        (component
          (role "R54_0")
        )
        (component
          (role "R54_1")
        )
      )
    )
    (cell
      "cell_55"
      (components
        (component
          (role "R55_0")
        )
        (component
          (role "R55_1")
        )
      )
    )
    (cell
      "cell_56"
      (components
        (component
          (role "R56_0")
        )
        (component
          (role "R56_1")
        )
      )
    )
    (cell
      "cell_57"
      (components
        (component
          (role "R57_0")
        )
        (component
          (role "R57_1")
        )
      )
    )
    (cell
      "cell_58"
      (components
        (component
          (role "R58_0")
        )
        (component
          (role "R58_1")
        )
      )
    )
    (cell
      "cell_59"
      (components
        (component
          (role "R59_0")
        )
        (component
          (role "R59_1")
        )
      )
    )
    (cell
      "cell_60"
      (components
        (component
          (role "R60_0")
        )
        (component
          (role "R60_1")
        )
      )
    )
    (cell
      "cell_61"
      (components
        (component
          (role "R61_0")
        )
        (component
          (role "R61_1")
        )
      )
    )
    (cell
      "cell_62"
      (components
        (component
          (role "R62_0")
        )
        (component
          (role "R62_1")
        )
      )
    )
    (cell
      "cell_63"
      (components
        (component
          (role "R63_0")
        )
        (component
          (role "R63_1")
        )
      )
    )
    (cell
      "cell_64"
      (components
        (component
          (role "R64_0")
        )
        (component
          (role "R64_1")
        )
      )
    )
    (cell
      "cell_65"
      (components
        (component
          (role "R65_0")
        )
        (component
          (role "R65_1")
        )
      )
    )
    (cell
      "cell_66"
      (components
        (component
          (role "R66_0")
        )
        (component
          (role "R66_1")
        )
      )
    )
    (cell
      "cell_67"
      (components
        (component
          (role "R67_0")
        )
        (component
          (role "R67_1")
        )
      )
    )
    (cell
      "cell_68"
      (components
        (component
          (role "R68_0")
        )
        (component
          (role "R68_1")
        )
      )
    )
    (cell
      "cell_69"
      (components
        (component
          (role "R69_0")
        )
        (component
          (role "R69_1")
        )
      )
    )
    (cell
      "cell_70"
      (components
        (component
          (role "R70_0")
        )
        (component
          (role "R70_1")
        )
      )
    )
    (cell
      "cell_71"
      (components
        (component
          (role "R71_0")
        )
        (component
          (role "R71_1")
        )
      )
    )
    (cell
      "cell_72"
      (components
        (component
          (role "R72_0")
        )
        (component
          (role "R72_1")
        )
      )
    )
    (cell
      "cell_73"
      (components
        (component
          (role "R73_0")
        )
        (component
          (role "R73_1")
        )
      )
    )
    (cell
      "cell_74"
      (components
        (component
          (role "R74_0")
        )
        (component
          (role "R74_1")
        )
      )
    )
    (cell
      "cell_75"
      (components
        (component
          (role "R75_0")
        )
        (component
          (role "R75_1")
        )
      )
    )
    (cell
      "cell_76"
      (components
        (component
          (role "R76_0")
        )
        (component
          (role "R76_1")
        )
      )
    )
    (cell
      "cell_77"
      (components
        (component
          (role "R77_0")
        )
        (component
          (role "R77_1")
        )
      )
    )
    (cell
      "cell_78"
      (components
        (component
          (role "R78_0")
        )
        (component
          (role "R78_1")
        )
      )
    )
    (cell
      "cell_79"
      (components
        (component
          (role "R79_0")
        )
        (component
          (role "R79_1")
        )
      )
    )
  )
  (rules
    (rule
      (net "NET_0")
      (name "rule_0")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "1")
          (cell "cell_0")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_1")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "2")
          (cell "cell_1")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_2")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "3")
          (cell "cell_2")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_3")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "4")
          (cell "cell_3")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_4")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "5")
          (cell "cell_4")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_5")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "6")
          (cell "cell_5")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_6")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "7")
          (cell "cell_6")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_7")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "8")
          (cell "cell_7")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_8")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "9")
          (cell "cell_8")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_9")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "10")
          (cell "cell_9")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_10")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "11")
          (cell "cell_10")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_11")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "12")
          (cell "cell_11")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_12")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "13")
          (cell "cell_12")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_13")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "14")
          (cell "cell_13")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_14")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "15")
          (cell "cell_14")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_15")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "16")
          (cell "cell_15")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_16")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "17")
          (cell "cell_16")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_17")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "18")
          (cell "cell_17")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_18")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "19")
          (cell "cell_18")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_19")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "20")
          (cell "cell_19")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_20")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "21")
          (cell "cell_20")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_21")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "22")
          (cell "cell_21")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_22")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "23")
          (cell "cell_22")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_23")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "24")
          (cell "cell_23")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_24")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "25")
          (cell "cell_24")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_25")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "26")
          (cell "cell_25")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_26")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "27")
          (cell "cell_26")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_27")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "28")
          (cell "cell_27")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_28")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "29")
          (cell "cell_28")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_29")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "30")
          (cell "cell_29")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_30")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "31")
          (cell "cell_30")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_31")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "32")
          (cell "cell_31")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_32")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "33")
          (cell "cell_32")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_33")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "34")
          (cell "cell_33")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_34")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "35")
          (cell "cell_34")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_35")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "36")
          (cell "cell_35")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_36")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "37")
          (cell "cell_36")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_37")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "38")
          (cell "cell_37")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_38")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "39")
          (cell "cell_38")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_39")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "40")
          (cell "cell_39")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_40")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "41")
          (cell "cell_40")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_41")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "42")
          (cell "cell_41")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_42")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "43")
          (cell "cell_42")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_43")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "44")
          (cell "cell_43")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_44")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "45")
          (cell "cell_44")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_45")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "46")
          (cell "cell_45")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_46")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "47")
          (cell "cell_46")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_47")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "48")
          (cell "cell_47")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_48")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "49")
          (cell "cell_48")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_49")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "50")
          (cell "cell_49")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_50")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "51")
          (cell "cell_50")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_51")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "52")
          (cell "cell_51")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_52")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "53")
          (cell "cell_52")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_53")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "54")
          (cell "cell_53")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_54")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "55")
          (cell "cell_54")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_55")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "56")
          (cell "cell_55")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_56")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "57")
          (cell "cell_56")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_57")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "58")
          (cell "cell_57")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_58")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "59")
          (cell "cell_58")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_59")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "60")
          (cell "cell_59")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_60")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "61")
          (cell "cell_60")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_61")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "62")
          (cell "cell_61")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_62")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "63")
          (cell "cell_62")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_63")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "64")
          (cell "cell_63")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_64")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "65")
          (cell "cell_64")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_65")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "66")
          (cell "cell_65")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_66")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "67")
          (cell "cell_66")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_67")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "68")
          (cell "cell_67")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_68")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "69")
          (cell "cell_68")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_69")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "70")
          (cell "cell_69")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_70")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "71")
          (cell "cell_70")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_71")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "72")
          (cell "cell_71")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_72")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "73")
          (cell "cell_72")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_73")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "74")
          (cell "cell_73")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_74")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "75")
          (cell "cell_74")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_75")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "76")
          (cell "cell_75")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_76")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "77")
          (cell "cell_76")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_77")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "78")
          (cell "cell_77")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_78")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "79")
          (cell "cell_78")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_79")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "80")
          (cell "cell_79")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_80")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "81")
          (cell "cell_0")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_81")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "82")
          (cell "cell_1")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_82")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "83")
          (cell "cell_2")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_83")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "84")
          (cell "cell_3")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_84")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "85")
          (cell "cell_4")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_85")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "86")
          (cell "cell_5")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_86")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "87")
          (cell "cell_6")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_87")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "88")
          (cell "cell_7")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_88")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "89")
          (cell "cell_8")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_89")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "90")
          (cell "cell_9")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_90")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "91")
          (cell "cell_10")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_91")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "92")
          (cell "cell_11")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_92")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "93")
          (cell "cell_12")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_93")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "94")
          (cell "cell_13")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_94")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "95")
          (cell "cell_14")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_95")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "96")
          (cell "cell_15")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_96")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "97")
          (cell "cell_16")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_97")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "98")
          (cell "cell_17")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_98")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "99")
          (cell "cell_18")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_99")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "100")
          (cell "cell_19")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_100")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "1")
          (cell "cell_20")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_101")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "2")
          (cell "cell_21")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_102")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "3")
          (cell "cell_22")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_103")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "4")
          (cell "cell_23")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_104")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "5")
          (cell "cell_24")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_105")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "6")
          (cell "cell_25")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_106")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "7")
          (cell "cell_26")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_107")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "8")
          (cell "cell_27")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_108")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "9")
          (cell "cell_28")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_109")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "10")
          (cell "cell_29")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_110")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "11")
          (cell "cell_30")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_111")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "12")
          (cell "cell_31")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_112")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "13")
          (cell "cell_32")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_113")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "14")
          (cell "cell_33")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_114")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "15")
          (cell "cell_34")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_115")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "16")
          (cell "cell_35")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_116")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "17")
          (cell "cell_36")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_117")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "18")
          (cell "cell_37")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_118")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "19")
          (cell "cell_38")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_119")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "20")
          (cell "cell_39")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_120")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "21")
          (cell "cell_40")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_121")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "22")
          (cell "cell_41")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_122")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "23")
          (cell "cell_42")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_123")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "24")
          (cell "cell_43")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_124")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "25")
          (cell "cell_44")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_125")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "26")
          (cell "cell_45")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_126")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "27")
          (cell "cell_46")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_127")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "28")
          (cell "cell_47")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_128")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "29")
          (cell "cell_48")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_129")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "30")
          (cell "cell_49")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_130")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "31")
          (cell "cell_50")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_131")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "32")
          (cell "cell_51")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_132")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "33")
          (cell "cell_52")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_133")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "34")
          (cell "cell_53")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_134")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "35")
          (cell "cell_54")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_135")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "36")
          (cell "cell_55")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_136")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "37")
          (cell "cell_56")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_137")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "38")
          (cell "cell_57")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_138")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "39")
          (cell "cell_58")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_139")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "40")
          (cell "cell_59")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_140")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "41")
          (cell "cell_60")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_141")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "42")
          (cell "cell_61")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_142")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "43")
          (cell "cell_62")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_143")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "44")
          (cell "cell_63")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_144")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "45")
          (cell "cell_64")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_145")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "46")
          (cell "cell_65")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_146")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "47")
          (cell "cell_66")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_147")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "48")
          (cell "cell_67")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_148")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "49")
          (cell "cell_68")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_149")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "50")
          (cell "cell_69")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_150")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "51")
          (cell "cell_70")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_151")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "52")
          (cell "cell_71")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_152")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "53")
          (cell "cell_72")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_153")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "54")
          (cell "cell_73")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_154")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "55")
          (cell "cell_74")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_155")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "56")
          (cell "cell_75")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_156")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "57")
          (cell "cell_76")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_157")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "58")
          (cell "cell_77")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_158")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "59")
          (cell "cell_78")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_159")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "60")
          (cell "cell_79")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_160")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "61")
          (cell "cell_0")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_161")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "62")
          (cell "cell_1")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_162")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "63")
          (cell "cell_2")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_163")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "64")
          (cell "cell_3")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_164")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "65")
          (cell "cell_4")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_165")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "66")
          (cell "cell_5")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_166")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "67")
          (cell "cell_6")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_167")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "68")
          (cell "cell_7")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_168")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "69")
          (cell "cell_8")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_169")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "70")
          (cell "cell_9")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_170")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "71")
          (cell "cell_10")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_171")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "72")
          (cell "cell_11")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_172")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "73")
          (cell "cell_12")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_173")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "74")
          (cell "cell_13")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_174")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "75")
          (cell "cell_14")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_175")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "76")
          (cell "cell_15")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_176")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "77")
          (cell "cell_16")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_177")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "78")
          (cell "cell_17")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_178")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "79")
          (cell "cell_18")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_179")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "80")
          (cell "cell_19")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_180")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "81")
          (cell "cell_20")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_181")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "82")
          (cell "cell_21")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_182")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "83")
          (cell "cell_22")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_183")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "84")
          (cell "cell_23")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_184")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "85")
          (cell "cell_24")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_185")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "86")
          (cell "cell_25")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_186")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "87")
          (cell "cell_26")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_187")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "88")
          (cell "cell_27")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_188")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "89")
          (cell "cell_28")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_189")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "90")
          (cell "cell_29")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_190")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "91")
          (cell "cell_30")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_191")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "92")
          (cell "cell_31")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_192")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "93")
          (cell "cell_32")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_193")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "94")
          (cell "cell_33")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_194")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "95")
          (cell "cell_34")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_195")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "96")
          (cell "cell_35")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_196")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "97")
          (cell "cell_36")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_197")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "98")
          (cell "cell_37")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_198")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "99")
          (cell "cell_38")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_199")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "100")
          (cell "cell_39")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_200")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "1")
          (cell "cell_40")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_201")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "2")
          (cell "cell_41")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_202")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "3")
          (cell "cell_42")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_203")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "4")
          (cell "cell_43")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_204")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "5")
          (cell "cell_44")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_205")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "6")
          (cell "cell_45")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_206")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "7")
          (cell "cell_46")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_207")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "8")
          (cell "cell_47")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_208")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "9")
          (cell "cell_48")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_209")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "10")
          (cell "cell_49")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_210")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "11")
          (cell "cell_50")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_211")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "12")
          (cell "cell_51")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_212")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "13")
          (cell "cell_52")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_213")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "14")
          (cell "cell_53")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_214")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "15")
          (cell "cell_54")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_215")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "16")
          (cell "cell_55")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_216")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "17")
          (cell "cell_56")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_217")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "18")
          (cell "cell_57")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_218")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "19")
          (cell "cell_58")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_219")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "20")
          (cell "cell_59")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_220")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "21")
          (cell "cell_60")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_221")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "22")
          (cell "cell_61")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_222")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "23")
          (cell "cell_62")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_223")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "24")
          (cell "cell_63")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_224")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "25")
          (cell "cell_64")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_225")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "26")
          (cell "cell_65")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_226")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "27")
          (cell "cell_66")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_227")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "28")
          (cell "cell_67")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_228")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "29")
          (cell "cell_68")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_229")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "30")
          (cell "cell_69")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_230")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "31")
          (cell "cell_70")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_231")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "32")
          (cell "cell_71")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_232")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "33")
          (cell "cell_72")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_233")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "34")
          (cell "cell_73")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_234")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "35")
          (cell "cell_74")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_235")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "36")
          (cell "cell_75")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_236")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "37")
          (cell "cell_76")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_237")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "38")
          (cell "cell_77")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_238")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "39")
          (cell "cell_78")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_239")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "40")
          (cell "cell_79")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_240")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "41")
          (cell "cell_0")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_241")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "42")
          (cell "cell_1")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_242")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "43")
          (cell "cell_2")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_243")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "44")
          (cell "cell_3")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_244")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "45")
          (cell "cell_4")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_245")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "46")
          (cell "cell_5")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_246")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "47")
          (cell "cell_6")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_247")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "48")
          (cell "cell_7")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_248")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "49")
          (cell "cell_8")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_249")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "50")
          (cell "cell_9")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_250")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "51")
          (cell "cell_10")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_251")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "52")
          (cell "cell_11")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_252")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "53")
          (cell "cell_12")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_253")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "54")
          (cell "cell_13")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_254")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "55")
          (cell "cell_14")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_255")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "56")
          (cell "cell_15")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_256")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "57")
          (cell "cell_16")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_257")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "58")
          (cell "cell_17")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_258")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "59")
          (cell "cell_18")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_259")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "60")
          (cell "cell_19")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_260")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "61")
          (cell "cell_20")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_261")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "62")
          (cell "cell_21")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_262")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "63")
          (cell "cell_22")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_263")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "64")
          (cell "cell_23")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_264")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "65")
          (cell "cell_24")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_265")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "66")
          (cell "cell_25")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_266")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "67")
          (cell "cell_26")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_267")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "68")
          (cell "cell_27")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_268")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "69")
          (cell "cell_28")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_269")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "70")
          (cell "cell_29")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_270")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "71")
          (cell "cell_30")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_271")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "72")
          (cell "cell_31")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_272")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "73")
          (cell "cell_32")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_273")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "74")
          (cell "cell_33")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_274")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "75")
          (cell "cell_34")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_275")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "76")
          (cell "cell_35")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_276")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "77")
          (cell "cell_36")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_277")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "78")
          (cell "cell_37")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_278")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "79")
          (cell "cell_38")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_279")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "80")
          (cell "cell_39")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_280")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "81")
          (cell "cell_40")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_281")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "82")
          (cell "cell_41")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_282")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "83")
          (cell "cell_42")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_283")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "84")
          (cell "cell_43")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_284")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "85")
          (cell "cell_44")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_285")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "86")
          (cell "cell_45")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_286")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "87")
          (cell "cell_46")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_287")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "88")
          (cell "cell_47")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_288")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "89")
          (cell "cell_48")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_289")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "90")
          (cell "cell_49")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_290")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "91")
          (cell "cell_50")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_291")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "92")
          (cell "cell_51")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_292")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "93")
          (cell "cell_52")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_293")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "94")
          (cell "cell_53")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_294")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "95")
          (cell "cell_54")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_295")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "96")
          (cell "cell_55")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_296")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "97")
          (cell "cell_56")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_297")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "98")
          (cell "cell_57")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_298")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "99")
          (cell "cell_58")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_299")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "100")
          (cell "cell_59")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_300")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "1")
          (cell "cell_60")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_301")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "2")
          (cell "cell_61")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_302")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "3")
          (cell "cell_62")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_303")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "4")
          (cell "cell_63")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_304")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "5")
          (cell "cell_64")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_305")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "6")
          (cell "cell_65")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_306")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "7")
          (cell "cell_66")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_307")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "8")
          (cell "cell_67")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_308")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "9")
          (cell "cell_68")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_309")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "10")
          (cell "cell_69")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_310")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "11")
          (cell "cell_70")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_311")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "12")
          (cell "cell_71")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_312")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "13")
          (cell "cell_72")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_313")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "14")
          (cell "cell_73")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_314")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "15")
          (cell "cell_74")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_315")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "16")
          (cell "cell_75")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_316")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "17")
          (cell "cell_76")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_317")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "18")
          (cell "cell_77")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_318")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "19")
          (cell "cell_78")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_319")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "20")
          (cell "cell_79")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_320")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "21")
          (cell "cell_0")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_321")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "22")
          (cell "cell_1")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_322")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "23")
          (cell "cell_2")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_323")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "24")
          (cell "cell_3")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_324")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "25")
          (cell "cell_4")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_325")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "26")
          (cell "cell_5")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_326")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "27")
          (cell "cell_6")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_327")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "28")
          (cell "cell_7")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_328")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "29")
          (cell "cell_8")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_329")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "30")
          (cell "cell_9")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_330")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "31")
          (cell "cell_10")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_331")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "32")
          (cell "cell_11")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_332")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "33")
          (cell "cell_12")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_333")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "34")
          (cell "cell_13")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_334")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "35")
          (cell "cell_14")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_335")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "36")
          (cell "cell_15")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_336")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "37")
          (cell "cell_16")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_337")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "38")
          (cell "cell_17")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_338")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "39")
          (cell "cell_18")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_339")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "40")
          (cell "cell_19")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_340")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "41")
          (cell "cell_20")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_341")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "42")
          (cell "cell_21")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_342")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "43")
          (cell "cell_22")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_343")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "44")
          (cell "cell_23")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_344")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "45")
          (cell "cell_24")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_345")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "46")
          (cell "cell_25")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_346")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "47")
          (cell "cell_26")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_347")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "48")
          (cell "cell_27")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_348")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "49")
          (cell "cell_28")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_349")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "50")
          (cell "cell_29")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_350")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "51")
          (cell "cell_30")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_351")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "52")
          (cell "cell_31")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_352")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "53")
          (cell "cell_32")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_353")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "54")
          (cell "cell_33")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_354")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "55")
          (cell "cell_34")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_355")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "56")
          (cell "cell_35")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_356")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "57")
          (cell "cell_36")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_357")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "58")
          (cell "cell_37")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_358")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "59")
          (cell "cell_38")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_359")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "60")
          (cell "cell_39")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_360")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "61")
          (cell "cell_40")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_361")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "62")
          (cell "cell_41")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_362")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "63")
          (cell "cell_42")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_363")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "64")
          (cell "cell_43")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_364")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "65")
          (cell "cell_44")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_365")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "66")
          (cell "cell_45")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_366")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "67")
          (cell "cell_46")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_367")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "68")
          (cell "cell_47")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_368")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "69")
          (cell "cell_48")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_369")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "70")
          (cell "cell_49")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_370")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "71")
          (cell "cell_50")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_371")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "72")
          (cell "cell_51")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_372")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "73")
          (cell "cell_52")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_373")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "74")
          (cell "cell_53")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_374")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "75")
          (cell "cell_54")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_375")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "76")
          (cell "cell_55")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_376")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "77")
          (cell "cell_56")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_377")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "78")
          (cell "cell_57")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_378")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "79")
          (cell "cell_58")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_379")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "80")
          (cell "cell_59")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_380")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "81")
          (cell "cell_60")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_381")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "82")
          (cell "cell_61")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_382")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "83")
          (cell "cell_62")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_383")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "84")
          (cell "cell_63")
        )
      )
    )
    (rule
      (net "NET_0")
      (name "rule_384")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "85")
          (cell "cell_64")
        )
      )
    )
    (rule
      (net "NET_1")
      (name "rule_385")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "86")
          (cell "cell_65")
        )
      )
    )
    (rule
      (net "NET_2")
      (name "rule_386")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "87")
          (cell "cell_66")
        )
      )
    )
    (rule
      (net "NET_3")
      (name "rule_387")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "88")
          (cell "cell_67")
        )
      )
    )
    (rule
      (net "NET_4")
      (name "rule_388")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "89")
          (cell "cell_68")
        )
      )
    )
    (rule
      (net "NET_5")
      (name "rule_389")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "90")
          (cell "cell_69")
        )
      )
    )
    (rule
      (net "NET_6")
      (name "rule_390")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "91")
          (cell "cell_70")
        )
      )
    )
    (rule
      (net "NET_7")
      (name "rule_391")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "92")
          (cell "cell_71")
        )
      )
    )
    (rule
      (net "NET_8")
      (name "rule_392")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "93")
          (cell "cell_72")
        )
      )
    )
    (rule
      (net "NET_9")
      (name "rule_393")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "94")
          (cell "cell_73")
        )
      )
    )
    (rule
      (net "NET_10")
      (name "rule_394")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "95")
          (cell "cell_74")
        )
      )
    )
    (rule
      (net "NET_11")
      (name "rule_395")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "96")
          (cell "cell_75")
        )
      )
    )
    (rule
      (net "NET_12")
      (name "rule_396")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "97")
          (cell "cell_76")
        )
      )
    )
    (rule
      (net "NET_13")
      (name "rule_397")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "98")
          (cell "cell_77")
        )
      )
    )
    (rule
      (net "NET_14")
      (name "rule_398")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "99")
          (cell "cell_78")
        )
      )
    )
    (rule
      (net "NET_15")
      (name "rule_399")
      (anchor_ref "IC1")
      (spokes
        (spoke
          (pad "100")
          (cell "cell_79")
        )
      )
    )
  )
  (clone_placements)
  (coordinate_placements
    (coordinate_placement
      (name "coord_0")
      (cluster "CL_0")
      (role "ROLE_0")
      (x_mm 0.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_1")
      (cluster "CL_1")
      (role "ROLE_1")
      (x_mm 1.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_2")
      (cluster "CL_2")
      (role "ROLE_2")
      (x_mm 2.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_3")
      (cluster "CL_3")
      (role "ROLE_3")
      (x_mm 3.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_4")
      (cluster "CL_4")
      (role "ROLE_4")
      (x_mm 4.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_5")
      (cluster "CL_5")
      (role "ROLE_5")
      (x_mm 5.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_6")
      (cluster "CL_6")
      (role "ROLE_6")
      (x_mm 6.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_7")
      (cluster "CL_7")
      (role "ROLE_7")
      (x_mm 7.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_8")
      (cluster "CL_8")
      (role "ROLE_8")
      (x_mm 8.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_9")
      (cluster "CL_9")
      (role "ROLE_9")
      (x_mm 9.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_10")
      (cluster "CL_10")
      (role "ROLE_10")
      (x_mm 10.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_11")
      (cluster "CL_11")
      (role "ROLE_11")
      (x_mm 11.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_12")
      (cluster "CL_12")
      (role "ROLE_12")
      (x_mm 12.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_13")
      (cluster "CL_13")
      (role "ROLE_13")
      (x_mm 13.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_14")
      (cluster "CL_14")
      (role "ROLE_14")
      (x_mm 14.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_15")
      (cluster "CL_15")
      (role "ROLE_15")
      (x_mm 15.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_16")
      (cluster "CL_16")
      (role "ROLE_16")
      (x_mm 16.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_17")
      (cluster "CL_17")
      (role "ROLE_17")
      (x_mm 17.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_18")
      (cluster "CL_18")
      (role "ROLE_18")
      (x_mm 18.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_19")
      (cluster "CL_19")
      (role "ROLE_19")
      (x_mm 19.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_20")
      (cluster "CL_20")
      (role "ROLE_20")
      (x_mm 20.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_21")
      (cluster "CL_21")
      (role "ROLE_21")
      (x_mm 21.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_22")
      (cluster "CL_22")
      (role "ROLE_22")
      (x_mm 22.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_23")
      (cluster "CL_23")
      (role "ROLE_23")
      (x_mm 23.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_24")
      (cluster "CL_24")
      (role "ROLE_24")
      (x_mm 24.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_25")
      (cluster "CL_25")
      (role "ROLE_25")
      (x_mm 25.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_26")
      (cluster "CL_26")
      (role "ROLE_26")
      (x_mm 26.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_27")
      (cluster "CL_27")
      (role "ROLE_27")
      (x_mm 27.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_28")
      (cluster "CL_28")
      (role "ROLE_28")
      (x_mm 28.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_29")
      (cluster "CL_29")
      (role "ROLE_29")
      (x_mm 29.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_30")
      (cluster "CL_30")
      (role "ROLE_30")
      (x_mm 30.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_31")
      (cluster "CL_31")
      (role "ROLE_31")
      (x_mm 31.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_32")
      (cluster "CL_32")
      (role "ROLE_32")
      (x_mm 32.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_33")
      (cluster "CL_33")
      (role "ROLE_33")
      (x_mm 33.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_34")
      (cluster "CL_34")
      (role "ROLE_34")
      (x_mm 34.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_35")
      (cluster "CL_35")
      (role "ROLE_35")
      (x_mm 35.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_36")
      (cluster "CL_36")
      (role "ROLE_36")
      (x_mm 36.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_37")
      (cluster "CL_37")
      (role "ROLE_37")
      (x_mm 37.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_38")
      (cluster "CL_38")
      (role "ROLE_38")
      (x_mm 38.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_39")
      (cluster "CL_39")
      (role "ROLE_39")
      (x_mm 39.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_40")
      (cluster "CL_40")
      (role "ROLE_40")
      (x_mm 40.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_41")
      (cluster "CL_41")
      (role "ROLE_41")
      (x_mm 41.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_42")
      (cluster "CL_42")
      (role "ROLE_42")
      (x_mm 42.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_43")
      (cluster "CL_43")
      (role "ROLE_43")
      (x_mm 43.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_44")
      (cluster "CL_44")
      (role "ROLE_44")
      (x_mm 44.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_45")
      (cluster "CL_45")
      (role "ROLE_45")
      (x_mm 45.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_46")
      (cluster "CL_46")
      (role "ROLE_46")
      (x_mm 46.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_47")
      (cluster "CL_47")
      (role "ROLE_47")
      (x_mm 47.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_48")
      (cluster "CL_48")
      (role "ROLE_48")
      (x_mm 48.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_49")
      (cluster "CL_49")
      (role "ROLE_49")
      (x_mm 49.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_50")
      (cluster "CL_50")
      (role "ROLE_50")
      (x_mm 50.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_51")
      (cluster "CL_51")
      (role "ROLE_51")
      (x_mm 51.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_52")
      (cluster "CL_52")
      (role "ROLE_52")
      (x_mm 52.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_53")
      (cluster "CL_53")
      (role "ROLE_53")
      (x_mm 53.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_54")
      (cluster "CL_54")
      (role "ROLE_54")
      (x_mm 54.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_55")
      (cluster "CL_55")
      (role "ROLE_55")
      (x_mm 55.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_56")
      (cluster "CL_56")
      (role "ROLE_56")
      (x_mm 56.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_57")
      (cluster "CL_57")
      (role "ROLE_57")
      (x_mm 57.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_58")
      (cluster "CL_58")
      (role "ROLE_58")
      (x_mm 58.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_59")
      (cluster "CL_59")
      (role "ROLE_59")
      (x_mm 59.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_60")
      (cluster "CL_60")
      (role "ROLE_60")
      (x_mm 60.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_61")
      (cluster "CL_61")
      (role "ROLE_61")
      (x_mm 61.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_62")
      (cluster "CL_62")
      (role "ROLE_62")
      (x_mm 62.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_63")
      (cluster "CL_63")
      (role "ROLE_63")
      (x_mm 63.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_64")
      (cluster "CL_64")
      (role "ROLE_64")
      (x_mm 64.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_65")
      (cluster "CL_65")
      (role "ROLE_65")
      (x_mm 65.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_66")
      (cluster "CL_66")
      (role "ROLE_66")
      (x_mm 66.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_67")
      (cluster "CL_67")
      (role "ROLE_67")
      (x_mm 67.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_68")
      (cluster "CL_68")
      (role "ROLE_68")
      (x_mm 68.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_69")
      (cluster "CL_69")
      (role "ROLE_69")
      (x_mm 69.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_70")
      (cluster "CL_70")
      (role "ROLE_70")
      (x_mm 70.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_71")
      (cluster "CL_71")
      (role "ROLE_71")
      (x_mm 71.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_72")
      (cluster "CL_72")
      (role "ROLE_72")
      (x_mm 72.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_73")
      (cluster "CL_73")
      (role "ROLE_73")
      (x_mm 73.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_74")
      (cluster "CL_74")
      (role "ROLE_74")
      (x_mm 74.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_75")
      (cluster "CL_75")
      (role "ROLE_75")
      (x_mm 75.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_76")
      (cluster "CL_76")
      (role "ROLE_76")
      (x_mm 76.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_77")
      (cluster "CL_77")
      (role "ROLE_77")
      (x_mm 77.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_78")
      (cluster "CL_78")
      (role "ROLE_78")
      (x_mm 78.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_79")
      (cluster "CL_79")
      (role "ROLE_79")
      (x_mm 79.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_80")
      (cluster "CL_80")
      (role "ROLE_80")
      (x_mm 80.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_81")
      (cluster "CL_81")
      (role "ROLE_81")
      (x_mm 81.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_82")
      (cluster "CL_82")
      (role "ROLE_82")
      (x_mm 82.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_83")
      (cluster "CL_83")
      (role "ROLE_83")
      (x_mm 83.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_84")
      (cluster "CL_84")
      (role "ROLE_84")
      (x_mm 84.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_85")
      (cluster "CL_85")
      (role "ROLE_85")
      (x_mm 85.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_86")
      (cluster "CL_86")
      (role "ROLE_86")
      (x_mm 86.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_87")
      (cluster "CL_87")
      (role "ROLE_87")
      (x_mm 87.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_88")
      (cluster "CL_88")
      (role "ROLE_88")
      (x_mm 88.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_89")
      (cluster "CL_89")
      (role "ROLE_89")
      (x_mm 89.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_90")
      (cluster "CL_90")
      (role "ROLE_90")
      (x_mm 90.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_91")
      (cluster "CL_91")
      (role "ROLE_91")
      (x_mm 91.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_92")
      (cluster "CL_92")
      (role "ROLE_92")
      (x_mm 92.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_93")
      (cluster "CL_93")
      (role "ROLE_93")
      (x_mm 93.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_94")
      (cluster "CL_94")
      (role "ROLE_94")
      (x_mm 94.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_95")
      (cluster "CL_95")
      (role "ROLE_95")
      (x_mm 95.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_96")
      (cluster "CL_96")
      (role "ROLE_96")
      (x_mm 96.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_97")
      (cluster "CL_97")
      (role "ROLE_97")
      (x_mm 97.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_98")
      (cluster "CL_98")
      (role "ROLE_98")
      (x_mm 98.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_99")
      (cluster "CL_99")
      (role "ROLE_99")
      (x_mm 99.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_100")
      (cluster "CL_100")
      (role "ROLE_100")
      (x_mm 100.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_101")
      (cluster "CL_101")
      (role "ROLE_101")
      (x_mm 101.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_102")
      (cluster "CL_102")
      (role "ROLE_102")
      (x_mm 102.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_103")
      (cluster "CL_103")
      (role "ROLE_103")
      (x_mm 103.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_104")
      (cluster "CL_104")
      (role "ROLE_104")
      (x_mm 104.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_105")
      (cluster "CL_105")
      (role "ROLE_105")
      (x_mm 105.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_106")
      (cluster "CL_106")
      (role "ROLE_106")
      (x_mm 106.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_107")
      (cluster "CL_107")
      (role "ROLE_107")
      (x_mm 107.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_108")
      (cluster "CL_108")
      (role "ROLE_108")
      (x_mm 108.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_109")
      (cluster "CL_109")
      (role "ROLE_109")
      (x_mm 109.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_110")
      (cluster "CL_110")
      (role "ROLE_110")
      (x_mm 110.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_111")
      (cluster "CL_111")
      (role "ROLE_111")
      (x_mm 111.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_112")
      (cluster "CL_112")
      (role "ROLE_112")
      (x_mm 112.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_113")
      (cluster "CL_113")
      (role "ROLE_113")
      (x_mm 113.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_114")
      (cluster "CL_114")
      (role "ROLE_114")
      (x_mm 114.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_115")
      (cluster "CL_115")
      (role "ROLE_115")
      (x_mm 115.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_116")
      (cluster "CL_116")
      (role "ROLE_116")
      (x_mm 116.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_117")
      (cluster "CL_117")
      (role "ROLE_117")
      (x_mm 117.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_118")
      (cluster "CL_118")
      (role "ROLE_118")
      (x_mm 118.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_119")
      (cluster "CL_119")
      (role "ROLE_119")
      (x_mm 119.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_120")
      (cluster "CL_120")
      (role "ROLE_120")
      (x_mm 120.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_121")
      (cluster "CL_121")
      (role "ROLE_121")
      (x_mm 121.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_122")
      (cluster "CL_122")
      (role "ROLE_122")
      (x_mm 122.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_123")
      (cluster "CL_123")
      (role "ROLE_123")
      (x_mm 123.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_124")
      (cluster "CL_124")
      (role "ROLE_124")
      (x_mm 124.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_125")
      (cluster "CL_125")
      (role "ROLE_125")
      (x_mm 125.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_126")
      (cluster "CL_126")
      (role "ROLE_126")
      (x_mm 126.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_127")
      (cluster "CL_127")
      (role "ROLE_127")
      (x_mm 127.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_128")
      (cluster "CL_128")
      (role "ROLE_128")
      (x_mm 128.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_129")
      (cluster "CL_129")
      (role "ROLE_129")
      (x_mm 129.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_130")
      (cluster "CL_130")
      (role "ROLE_130")
      (x_mm 130.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_131")
      (cluster "CL_131")
      (role "ROLE_131")
      (x_mm 131.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_132")
      (cluster "CL_132")
      (role "ROLE_132")
      (x_mm 132.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_133")
      (cluster "CL_133")
      (role "ROLE_133")
      (x_mm 133.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_134")
      (cluster "CL_134")
      (role "ROLE_134")
      (x_mm 134.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_135")
      (cluster "CL_135")
      (role "ROLE_135")
      (x_mm 135.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_136")
      (cluster "CL_136")
      (role "ROLE_136")
      (x_mm 136.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_137")
      (cluster "CL_137")
      (role "ROLE_137")
      (x_mm 137.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_138")
      (cluster "CL_138")
      (role "ROLE_138")
      (x_mm 138.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_139")
      (cluster "CL_139")
      (role "ROLE_139")
      (x_mm 139.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_140")
      (cluster "CL_140")
      (role "ROLE_140")
      (x_mm 140.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_141")
      (cluster "CL_141")
      (role "ROLE_141")
      (x_mm 141.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_142")
      (cluster "CL_142")
      (role "ROLE_142")
      (x_mm 142.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_143")
      (cluster "CL_143")
      (role "ROLE_143")
      (x_mm 143.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_144")
      (cluster "CL_144")
      (role "ROLE_144")
      (x_mm 144.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_145")
      (cluster "CL_145")
      (role "ROLE_145")
      (x_mm 145.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_146")
      (cluster "CL_146")
      (role "ROLE_146")
      (x_mm 146.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_147")
      (cluster "CL_147")
      (role "ROLE_147")
      (x_mm 147.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_148")
      (cluster "CL_148")
      (role "ROLE_148")
      (x_mm 148.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_149")
      (cluster "CL_149")
      (role "ROLE_149")
      (x_mm 149.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_150")
      (cluster "CL_150")
      (role "ROLE_150")
      (x_mm 150.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_151")
      (cluster "CL_151")
      (role "ROLE_151")
      (x_mm 151.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_152")
      (cluster "CL_152")
      (role "ROLE_152")
      (x_mm 152.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_153")
      (cluster "CL_153")
      (role "ROLE_153")
      (x_mm 153.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_154")
      (cluster "CL_154")
      (role "ROLE_154")
      (x_mm 154.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_155")
      (cluster "CL_155")
      (role "ROLE_155")
      (x_mm 155.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_156")
      (cluster "CL_156")
      (role "ROLE_156")
      (x_mm 156.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_157")
      (cluster "CL_157")
      (role "ROLE_157")
      (x_mm 157.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_158")
      (cluster "CL_158")
      (role "ROLE_158")
      (x_mm 158.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_159")
      (cluster "CL_159")
      (role "ROLE_159")
      (x_mm 159.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_160")
      (cluster "CL_160")
      (role "ROLE_160")
      (x_mm 160.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_161")
      (cluster "CL_161")
      (role "ROLE_161")
      (x_mm 161.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_162")
      (cluster "CL_162")
      (role "ROLE_162")
      (x_mm 162.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_163")
      (cluster "CL_163")
      (role "ROLE_163")
      (x_mm 163.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_164")
      (cluster "CL_164")
      (role "ROLE_164")
      (x_mm 164.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_165")
      (cluster "CL_165")
      (role "ROLE_165")
      (x_mm 165.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_166")
      (cluster "CL_166")
      (role "ROLE_166")
      (x_mm 166.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_167")
      (cluster "CL_167")
      (role "ROLE_167")
      (x_mm 167.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_168")
      (cluster "CL_168")
      (role "ROLE_168")
      (x_mm 168.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_169")
      (cluster "CL_169")
      (role "ROLE_169")
      (x_mm 169.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_170")
      (cluster "CL_170")
      (role "ROLE_170")
      (x_mm 170.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_171")
      (cluster "CL_171")
      (role "ROLE_171")
      (x_mm 171.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_172")
      (cluster "CL_172")
      (role "ROLE_172")
      (x_mm 172.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_173")
      (cluster "CL_173")
      (role "ROLE_173")
      (x_mm 173.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_174")
      (cluster "CL_174")
      (role "ROLE_174")
      (x_mm 174.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_175")
      (cluster "CL_175")
      (role "ROLE_175")
      (x_mm 175.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_176")
      (cluster "CL_176")
      (role "ROLE_176")
      (x_mm 176.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_177")
      (cluster "CL_177")
      (role "ROLE_177")
      (x_mm 177.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_178")
      (cluster "CL_178")
      (role "ROLE_178")
      (x_mm 178.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_179")
      (cluster "CL_179")
      (role "ROLE_179")
      (x_mm 179.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_180")
      (cluster "CL_180")
      (role "ROLE_180")
      (x_mm 180.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_181")
      (cluster "CL_181")
      (role "ROLE_181")
      (x_mm 181.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_182")
      (cluster "CL_182")
      (role "ROLE_182")
      (x_mm 182.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_183")
      (cluster "CL_183")
      (role "ROLE_183")
      (x_mm 183.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_184")
      (cluster "CL_184")
      (role "ROLE_184")
      (x_mm 184.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_185")
      (cluster "CL_185")
      (role "ROLE_185")
      (x_mm 185.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_186")
      (cluster "CL_186")
      (role "ROLE_186")
      (x_mm 186.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_187")
      (cluster "CL_187")
      (role "ROLE_187")
      (x_mm 187.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_188")
      (cluster "CL_188")
      (role "ROLE_188")
      (x_mm 188.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_189")
      (cluster "CL_189")
      (role "ROLE_189")
      (x_mm 189.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_190")
      (cluster "CL_190")
      (role "ROLE_190")
      (x_mm 190.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_191")
      (cluster "CL_191")
      (role "ROLE_191")
      (x_mm 191.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_192")
      (cluster "CL_192")
      (role "ROLE_192")
      (x_mm 192.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_193")
      (cluster "CL_193")
      (role "ROLE_193")
      (x_mm 193.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_194")
      (cluster "CL_194")
      (role "ROLE_194")
      (x_mm 194.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_195")
      (cluster "CL_195")
      (role "ROLE_195")
      (x_mm 195.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_196")
      (cluster "CL_196")
      (role "ROLE_196")
      (x_mm 196.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_197")
      (cluster "CL_197")
      (role "ROLE_197")
      (x_mm 197.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_198")
      (cluster "CL_198")
      (role "ROLE_198")
      (x_mm 198.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_199")
      (cluster "CL_199")
      (role "ROLE_199")
      (x_mm 199.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_200")
      (cluster "CL_200")
      (role "ROLE_200")
      (x_mm 200.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_201")
      (cluster "CL_201")
      (role "ROLE_201")
      (x_mm 201.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_202")
      (cluster "CL_202")
      (role "ROLE_202")
      (x_mm 202.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_203")
      (cluster "CL_203")
      (role "ROLE_203")
      (x_mm 203.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_204")
      (cluster "CL_204")
      (role "ROLE_204")
      (x_mm 204.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_205")
      (cluster "CL_205")
      (role "ROLE_205")
      (x_mm 205.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_206")
      (cluster "CL_206")
      (role "ROLE_206")
      (x_mm 206.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_207")
      (cluster "CL_207")
      (role "ROLE_207")
      (x_mm 207.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_208")
      (cluster "CL_208")
      (role "ROLE_208")
      (x_mm 208.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_209")
      (cluster "CL_209")
      (role "ROLE_209")
      (x_mm 209.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_210")
      (cluster "CL_210")
      (role "ROLE_210")
      (x_mm 210.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_211")
      (cluster "CL_211")
      (role "ROLE_211")
      (x_mm 211.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_212")
      (cluster "CL_212")
      (role "ROLE_212")
      (x_mm 212.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_213")
      (cluster "CL_213")
      (role "ROLE_213")
      (x_mm 213.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_214")
      (cluster "CL_214")
      (role "ROLE_214")
      (x_mm 214.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_215")
      (cluster "CL_215")
      (role "ROLE_215")
      (x_mm 215.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_216")
      (cluster "CL_216")
      (role "ROLE_216")
      (x_mm 216.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_217")
      (cluster "CL_217")
      (role "ROLE_217")
      (x_mm 217.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_218")
      (cluster "CL_218")
      (role "ROLE_218")
      (x_mm 218.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_219")
      (cluster "CL_219")
      (role "ROLE_219")
      (x_mm 219.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_220")
      (cluster "CL_220")
      (role "ROLE_220")
      (x_mm 220.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_221")
      (cluster "CL_221")
      (role "ROLE_221")
      (x_mm 221.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_222")
      (cluster "CL_222")
      (role "ROLE_222")
      (x_mm 222.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_223")
      (cluster "CL_223")
      (role "ROLE_223")
      (x_mm 223.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_224")
      (cluster "CL_224")
      (role "ROLE_224")
      (x_mm 224.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_225")
      (cluster "CL_225")
      (role "ROLE_225")
      (x_mm 225.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_226")
      (cluster "CL_226")
      (role "ROLE_226")
      (x_mm 226.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_227")
      (cluster "CL_227")
      (role "ROLE_227")
      (x_mm 227.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_228")
      (cluster "CL_228")
      (role "ROLE_228")
      (x_mm 228.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_229")
      (cluster "CL_229")
      (role "ROLE_229")
      (x_mm 229.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_230")
      (cluster "CL_230")
      (role "ROLE_230")
      (x_mm 230.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_231")
      (cluster "CL_231")
      (role "ROLE_231")
      (x_mm 231.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_232")
      (cluster "CL_232")
      (role "ROLE_232")
      (x_mm 232.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_233")
      (cluster "CL_233")
      (role "ROLE_233")
      (x_mm 233.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_234")
      (cluster "CL_234")
      (role "ROLE_234")
      (x_mm 234.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_235")
      (cluster "CL_235")
      (role "ROLE_235")
      (x_mm 235.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_236")
      (cluster "CL_236")
      (role "ROLE_236")
      (x_mm 236.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_237")
      (cluster "CL_237")
      (role "ROLE_237")
      (x_mm 237.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_238")
      (cluster "CL_238")
      (role "ROLE_238")
      (x_mm 238.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_239")
      (cluster "CL_239")
      (role "ROLE_239")
      (x_mm 239.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_240")
      (cluster "CL_240")
      (role "ROLE_240")
      (x_mm 240.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_241")
      (cluster "CL_241")
      (role "ROLE_241")
      (x_mm 241.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_242")
      (cluster "CL_242")
      (role "ROLE_242")
      (x_mm 242.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_243")
      (cluster "CL_243")
      (role "ROLE_243")
      (x_mm 243.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_244")
      (cluster "CL_244")
      (role "ROLE_244")
      (x_mm 244.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_245")
      (cluster "CL_245")
      (role "ROLE_245")
      (x_mm 245.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_246")
      (cluster "CL_246")
      (role "ROLE_246")
      (x_mm 246.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_247")
      (cluster "CL_247")
      (role "ROLE_247")
      (x_mm 247.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_248")
      (cluster "CL_248")
      (role "ROLE_248")
      (x_mm 248.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_249")
      (cluster "CL_249")
      (role "ROLE_249")
      (x_mm 249.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_250")
      (cluster "CL_250")
      (role "ROLE_250")
      (x_mm 250.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_251")
      (cluster "CL_251")
      (role "ROLE_251")
      (x_mm 251.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_252")
      (cluster "CL_252")
      (role "ROLE_252")
      (x_mm 252.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_253")
      (cluster "CL_253")
      (role "ROLE_253")
      (x_mm 253.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_254")
      (cluster "CL_254")
      (role "ROLE_254")
      (x_mm 254.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_255")
      (cluster "CL_255")
      (role "ROLE_255")
      (x_mm 255.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_256")
      (cluster "CL_256")
      (role "ROLE_256")
      (x_mm 256.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_257")
      (cluster "CL_257")
      (role "ROLE_257")
      (x_mm 257.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_258")
      (cluster "CL_258")
      (role "ROLE_258")
      (x_mm 258.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_259")
      (cluster "CL_259")
      (role "ROLE_259")
      (x_mm 259.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_260")
      (cluster "CL_260")
      (role "ROLE_260")
      (x_mm 260.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_261")
      (cluster "CL_261")
      (role "ROLE_261")
      (x_mm 261.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_262")
      (cluster "CL_262")
      (role "ROLE_262")
      (x_mm 262.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_263")
      (cluster "CL_263")
      (role "ROLE_263")
      (x_mm 263.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_264")
      (cluster "CL_264")
      (role "ROLE_264")
      (x_mm 264.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_265")
      (cluster "CL_265")
      (role "ROLE_265")
      (x_mm 265.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_266")
      (cluster "CL_266")
      (role "ROLE_266")
      (x_mm 266.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_267")
      (cluster "CL_267")
      (role "ROLE_267")
      (x_mm 267.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_268")
      (cluster "CL_268")
      (role "ROLE_268")
      (x_mm 268.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_269")
      (cluster "CL_269")
      (role "ROLE_269")
      (x_mm 269.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_270")
      (cluster "CL_270")
      (role "ROLE_270")
      (x_mm 270.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_271")
      (cluster "CL_271")
      (role "ROLE_271")
      (x_mm 271.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_272")
      (cluster "CL_272")
      (role "ROLE_272")
      (x_mm 272.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_273")
      (cluster "CL_273")
      (role "ROLE_273")
      (x_mm 273.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_274")
      (cluster "CL_274")
      (role "ROLE_274")
      (x_mm 274.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_275")
      (cluster "CL_275")
      (role "ROLE_275")
      (x_mm 275.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_276")
      (cluster "CL_276")
      (role "ROLE_276")
      (x_mm 276.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_277")
      (cluster "CL_277")
      (role "ROLE_277")
      (x_mm 277.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_278")
      (cluster "CL_278")
      (role "ROLE_278")
      (x_mm 278.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_279")
      (cluster "CL_279")
      (role "ROLE_279")
      (x_mm 279.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_280")
      (cluster "CL_280")
      (role "ROLE_280")
      (x_mm 280.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_281")
      (cluster "CL_281")
      (role "ROLE_281")
      (x_mm 281.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_282")
      (cluster "CL_282")
      (role "ROLE_282")
      (x_mm 282.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_283")
      (cluster "CL_283")
      (role "ROLE_283")
      (x_mm 283.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_284")
      (cluster "CL_284")
      (role "ROLE_284")
      (x_mm 284.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_285")
      (cluster "CL_285")
      (role "ROLE_285")
      (x_mm 285.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_286")
      (cluster "CL_286")
      (role "ROLE_286")
      (x_mm 286.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_287")
      (cluster "CL_287")
      (role "ROLE_287")
      (x_mm 287.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_288")
      (cluster "CL_288")
      (role "ROLE_288")
      (x_mm 288.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_289")
      (cluster "CL_289")
      (role "ROLE_289")
      (x_mm 289.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_290")
      (cluster "CL_290")
      (role "ROLE_290")
      (x_mm 290.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_291")
      (cluster "CL_291")
      (role "ROLE_291")
      (x_mm 291.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_292")
      (cluster "CL_292")
      (role "ROLE_292")
      (x_mm 292.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_293")
      (cluster "CL_293")
      (role "ROLE_293")
      (x_mm 293.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_294")
      (cluster "CL_294")
      (role "ROLE_294")
      (x_mm 294.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_295")
      (cluster "CL_295")
      (role "ROLE_295")
      (x_mm 295.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_296")
      (cluster "CL_296")
      (role "ROLE_296")
      (x_mm 296.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_297")
      (cluster "CL_297")
      (role "ROLE_297")
      (x_mm 297.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_298")
      (cluster "CL_298")
      (role "ROLE_298")
      (x_mm 298.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
    (coordinate_placement
      (name "coord_299")
      (cluster "CL_299")
      (role "ROLE_299")
      (x_mm 299.0)
      (y_mm 0.0)
      (rotation_deg 0.0)
    )
  )
  (thermal_via_arrays
    (thermal_via_array
      (name "thermal_0")
      (anchor_ref "IC1")
      (pad "1")
    )
    (thermal_via_array
      (name "thermal_1")
      (anchor_ref "IC1")
      (pad "2")
    )
    (thermal_via_array
      (name "thermal_2")
      (anchor_ref "IC1")
      (pad "3")
    )
    (thermal_via_array
      (name "thermal_3")
      (anchor_ref "IC1")
      (pad "4")
    )
    (thermal_via_array
      (name "thermal_4")
      (anchor_ref "IC1")
      (pad "5")
    )
    (thermal_via_array
      (name "thermal_5")
      (anchor_ref "IC1")
      (pad "6")
    )
    (thermal_via_array
      (name "thermal_6")
      (anchor_ref "IC1")
      (pad "7")
    )
    (thermal_via_array
      (name "thermal_7")
      (anchor_ref "IC1")
      (pad "8")
    )
    (thermal_via_array
      (name "thermal_8")
      (anchor_ref "IC1")
      (pad "9")
    )
    (thermal_via_array
      (name "thermal_9")
      (anchor_ref "IC1")
      (pad "10")
    )
    (thermal_via_array
      (name "thermal_10")
      (anchor_ref "IC1")
      (pad "11")
    )
    (thermal_via_array
      (name "thermal_11")
      (anchor_ref "IC1")
      (pad "12")
    )
    (thermal_via_array
      (name "thermal_12")
      (anchor_ref "IC1")
      (pad "13")
    )
    (thermal_via_array
      (name "thermal_13")
      (anchor_ref "IC1")
      (pad "14")
    )
    (thermal_via_array
      (name "thermal_14")
      (anchor_ref "IC1")
      (pad "15")
    )
    (thermal_via_array
      (name "thermal_15")
      (anchor_ref "IC1")
      (pad "16")
    )
    (thermal_via_array
      (name "thermal_16")
      (anchor_ref "IC1")
      (pad "17")
    )
    (thermal_via_array
      (name "thermal_17")
      (anchor_ref "IC1")
      (pad "18")
    )
    (thermal_via_array
      (name "thermal_18")
      (anchor_ref "IC1")
      (pad "19")
    )
    (thermal_via_array
      (name "thermal_19")
      (anchor_ref "IC1")
      (pad "20")
    )
    (thermal_via_array
      (name "thermal_20")
      (anchor_ref "IC1")
      (pad "21")
    )
    (thermal_via_array
      (name "thermal_21")
      (anchor_ref "IC1")
      (pad "22")
    )
    (thermal_via_array
      (name "thermal_22")
      (anchor_ref "IC1")
      (pad "23")
    )
    (thermal_via_array
      (name "thermal_23")
      (anchor_ref "IC1")
      (pad "24")
    )
    (thermal_via_array
      (name "thermal_24")
      (anchor_ref "IC1")
      (pad "25")
    )
    (thermal_via_array
      (name "thermal_25")
      (anchor_ref "IC1")
      (pad "26")
    )
    (thermal_via_array
      (name "thermal_26")
      (anchor_ref "IC1")
      (pad "27")
    )
    (thermal_via_array
      (name "thermal_27")
      (anchor_ref "IC1")
      (pad "28")
    )
    (thermal_via_array
      (name "thermal_28")
      (anchor_ref "IC1")
      (pad "29")
    )
    (thermal_via_array
      (name "thermal_29")
      (anchor_ref "IC1")
      (pad "30")
    )
    (thermal_via_array
      (name "thermal_30")
      (anchor_ref "IC1")
      (pad "31")
    )
    (thermal_via_array
      (name "thermal_31")
      (anchor_ref "IC1")
      (pad "32")
    )
    (thermal_via_array
      (name "thermal_32")
      (anchor_ref "IC1")
      (pad "33")
    )
    (thermal_via_array
      (name "thermal_33")
      (anchor_ref "IC1")
      (pad "34")
    )
    (thermal_via_array
      (name "thermal_34")
      (anchor_ref "IC1")
      (pad "35")
    )
    (thermal_via_array
      (name "thermal_35")
      (anchor_ref "IC1")
      (pad "36")
    )
    (thermal_via_array
      (name "thermal_36")
      (anchor_ref "IC1")
      (pad "37")
    )
    (thermal_via_array
      (name "thermal_37")
      (anchor_ref "IC1")
      (pad "38")
    )
    (thermal_via_array
      (name "thermal_38")
      (anchor_ref "IC1")
      (pad "39")
    )
    (thermal_via_array
      (name "thermal_39")
      (anchor_ref "IC1")
      (pad "40")
    )
    (thermal_via_array
      (name "thermal_40")
      (anchor_ref "IC1")
      (pad "41")
    )
    (thermal_via_array
      (name "thermal_41")
      (anchor_ref "IC1")
      (pad "42")
    )
    (thermal_via_array
      (name "thermal_42")
      (anchor_ref "IC1")
      (pad "43")
    )
    (thermal_via_array
      (name "thermal_43")
      (anchor_ref "IC1")
      (pad "44")
    )
    (thermal_via_array
      (name "thermal_44")
      (anchor_ref "IC1")
      (pad "45")
    )
    (thermal_via_array
      (name "thermal_45")
      (anchor_ref "IC1")
      (pad "46")
    )
    (thermal_via_array
      (name "thermal_46")
      (anchor_ref "IC1")
      (pad "47")
    )
    (thermal_via_array
      (name "thermal_47")
      (anchor_ref "IC1")
      (pad "48")
    )
    (thermal_via_array
      (name "thermal_48")
      (anchor_ref "IC1")
      (pad "49")
    )
    (thermal_via_array
      (name "thermal_49")
      (anchor_ref "IC1")
      (pad "50")
    )
    (thermal_via_array
      (name "thermal_50")
      (anchor_ref "IC1")
      (pad "51")
    )
    (thermal_via_array
      (name "thermal_51")
      (anchor_ref "IC1")
      (pad "52")
    )
    (thermal_via_array
      (name "thermal_52")
      (anchor_ref "IC1")
      (pad "53")
    )
    (thermal_via_array
      (name "thermal_53")
      (anchor_ref "IC1")
      (pad "54")
    )
    (thermal_via_array
      (name "thermal_54")
      (anchor_ref "IC1")
      (pad "55")
    )
    (thermal_via_array
      (name "thermal_55")
      (anchor_ref "IC1")
      (pad "56")
    )
    (thermal_via_array
      (name "thermal_56")
      (anchor_ref "IC1")
      (pad "57")
    )
    (thermal_via_array
      (name "thermal_57")
      (anchor_ref "IC1")
      (pad "58")
    )
    (thermal_via_array
      (name "thermal_58")
      (anchor_ref "IC1")
      (pad "59")
    )
    (thermal_via_array
      (name "thermal_59")
      (anchor_ref "IC1")
      (pad "60")
    )
    (thermal_via_array
      (name "thermal_60")
      (anchor_ref "IC1")
      (pad "61")
    )
    (thermal_via_array
      (name "thermal_61")
      (anchor_ref "IC1")
      (pad "62")
    )
    (thermal_via_array
      (name "thermal_62")
      (anchor_ref "IC1")
      (pad "63")
    )
    (thermal_via_array
      (name "thermal_63")
      (anchor_ref "IC1")
      (pad "64")
    )
    (thermal_via_array
      (name "thermal_64")
      (anchor_ref "IC1")
      (pad "65")
    )
    (thermal_via_array
      (name "thermal_65")
      (anchor_ref "IC1")
      (pad "66")
    )
    (thermal_via_array
      (name "thermal_66")
      (anchor_ref "IC1")
      (pad "67")
    )
    (thermal_via_array
      (name "thermal_67")
      (anchor_ref "IC1")
      (pad "68")
    )
    (thermal_via_array
      (name "thermal_68")
      (anchor_ref "IC1")
      (pad "69")
    )
    (thermal_via_array
      (name "thermal_69")
      (anchor_ref "IC1")
      (pad "70")
    )
    (thermal_via_array
      (name "thermal_70")
      (anchor_ref "IC1")
      (pad "71")
    )
    (thermal_via_array
      (name "thermal_71")
      (anchor_ref "IC1")
      (pad "72")
    )
    (thermal_via_array
      (name "thermal_72")
      (anchor_ref "IC1")
      (pad "73")
    )
    (thermal_via_array
      (name "thermal_73")
      (anchor_ref "IC1")
      (pad "74")
    )
    (thermal_via_array
      (name "thermal_74")
      (anchor_ref "IC1")
      (pad "75")
    )
    (thermal_via_array
      (name "thermal_75")
      (anchor_ref "IC1")
      (pad "76")
    )
    (thermal_via_array
      (name "thermal_76")
      (anchor_ref "IC1")
      (pad "77")
    )
    (thermal_via_array
      (name "thermal_77")
      (anchor_ref "IC1")
      (pad "78")
    )
    (thermal_via_array
      (name "thermal_78")
      (anchor_ref "IC1")
      (pad "79")
    )
    (thermal_via_array
      (name "thermal_79")
      (anchor_ref "IC1")
      (pad "80")
    )
    (thermal_via_array
      (name "thermal_80")
      (anchor_ref "IC1")
      (pad "81")
    )
    (thermal_via_array
      (name "thermal_81")
      (anchor_ref "IC1")
      (pad "82")
    )
    (thermal_via_array
      (name "thermal_82")
      (anchor_ref "IC1")
      (pad "83")
    )
    (thermal_via_array
      (name "thermal_83")
      (anchor_ref "IC1")
      (pad "84")
    )
    (thermal_via_array
      (name "thermal_84")
      (anchor_ref "IC1")
      (pad "85")
    )
    (thermal_via_array
      (name "thermal_85")
      (anchor_ref "IC1")
      (pad "86")
    )
    (thermal_via_array
      (name "thermal_86")
      (anchor_ref "IC1")
      (pad "87")
    )
    (thermal_via_array
      (name "thermal_87")
      (anchor_ref "IC1")
      (pad "88")
    )
    (thermal_via_array
      (name "thermal_88")
      (anchor_ref "IC1")
      (pad "89")
    )
    (thermal_via_array
      (name "thermal_89")
      (anchor_ref "IC1")
      (pad "90")
    )
    (thermal_via_array
      (name "thermal_90")
      (anchor_ref "IC1")
      (pad "91")
    )
    (thermal_via_array
      (name "thermal_91")
      (anchor_ref "IC1")
      (pad "92")
    )
    (thermal_via_array
      (name "thermal_92")
      (anchor_ref "IC1")
      (pad "93")
    )
    (thermal_via_array
      (name "thermal_93")
      (anchor_ref "IC1")
      (pad "94")
    )
    (thermal_via_array
      (name "thermal_94")
      (anchor_ref "IC1")
      (pad "95")
    )
    (thermal_via_array
      (name "thermal_95")
      (anchor_ref "IC1")
      (pad "96")
    )
    (thermal_via_array
      (name "thermal_96")
      (anchor_ref "IC1")
      (pad "97")
    )
    (thermal_via_array
      (name "thermal_97")
      (anchor_ref "IC1")
      (pad "98")
    )
    (thermal_via_array
      (name "thermal_98")
      (anchor_ref "IC1")
      (pad "99")
    )
    (thermal_via_array
      (name "thermal_99")
      (anchor_ref "IC1")
      (pad "100")
    )
    (thermal_via_array
      (name "thermal_100")
      (anchor_ref "IC1")
      (pad "1")
    )
    (thermal_via_array
      (name "thermal_101")
      (anchor_ref "IC1")
      (pad "2")
    )
    (thermal_via_array
      (name "thermal_102")
      (anchor_ref "IC1")
      (pad "3")
    )
    (thermal_via_array
      (name "thermal_103")
      (anchor_ref "IC1")
      (pad "4")
    )
    (thermal_via_array
      (name "thermal_104")
      (anchor_ref "IC1")
      (pad "5")
    )
    (thermal_via_array
      (name "thermal_105")
      (anchor_ref "IC1")
      (pad "6")
    )
    (thermal_via_array
      (name "thermal_106")
      (anchor_ref "IC1")
      (pad "7")
    )
    (thermal_via_array
      (name "thermal_107")
      (anchor_ref "IC1")
      (pad "8")
    )
    (thermal_via_array
      (name "thermal_108")
      (anchor_ref "IC1")
      (pad "9")
    )
    (thermal_via_array
      (name "thermal_109")
      (anchor_ref "IC1")
      (pad "10")
    )
    (thermal_via_array
      (name "thermal_110")
      (anchor_ref "IC1")
      (pad "11")
    )
    (thermal_via_array
      (name "thermal_111")
      (anchor_ref "IC1")
      (pad "12")
    )
    (thermal_via_array
      (name "thermal_112")
      (anchor_ref "IC1")
      (pad "13")
    )
    (thermal_via_array
      (name "thermal_113")
      (anchor_ref "IC1")
      (pad "14")
    )
    (thermal_via_array
      (name "thermal_114")
      (anchor_ref "IC1")
      (pad "15")
    )
    (thermal_via_array
      (name "thermal_115")
      (anchor_ref "IC1")
      (pad "16")
    )
    (thermal_via_array
      (name "thermal_116")
      (anchor_ref "IC1")
      (pad "17")
    )
    (thermal_via_array
      (name "thermal_117")
      (anchor_ref "IC1")
      (pad "18")
    )
    (thermal_via_array
      (name "thermal_118")
      (anchor_ref "IC1")
      (pad "19")
    )
    (thermal_via_array
      (name "thermal_119")
      (anchor_ref "IC1")
      (pad "20")
    )
    (thermal_via_array
      (name "thermal_120")
      (anchor_ref "IC1")
      (pad "21")
    )
    (thermal_via_array
      (name "thermal_121")
      (anchor_ref "IC1")
      (pad "22")
    )
    (thermal_via_array
      (name "thermal_122")
      (anchor_ref "IC1")
      (pad "23")
    )
    (thermal_via_array
      (name "thermal_123")
      (anchor_ref "IC1")
      (pad "24")
    )
    (thermal_via_array
      (name "thermal_124")
      (anchor_ref "IC1")
      (pad "25")
    )
    (thermal_via_array
      (name "thermal_125")
      (anchor_ref "IC1")
      (pad "26")
    )
    (thermal_via_array
      (name "thermal_126")
      (anchor_ref "IC1")
      (pad "27")
    )
    (thermal_via_array
      (name "thermal_127")
      (anchor_ref "IC1")
      (pad "28")
    )
    (thermal_via_array
      (name "thermal_128")
      (anchor_ref "IC1")
      (pad "29")
    )
    (thermal_via_array
      (name "thermal_129")
      (anchor_ref "IC1")
      (pad "30")
    )
    (thermal_via_array
      (name "thermal_130")
      (anchor_ref "IC1")
      (pad "31")
    )
    (thermal_via_array
      (name "thermal_131")
      (anchor_ref "IC1")
      (pad "32")
    )
    (thermal_via_array
      (name "thermal_132")
      (anchor_ref "IC1")
      (pad "33")
    )
    (thermal_via_array
      (name "thermal_133")
      (anchor_ref "IC1")
      (pad "34")
    )
    (thermal_via_array
      (name "thermal_134")
      (anchor_ref "IC1")
      (pad "35")
    )
    (thermal_via_array
      (name "thermal_135")
      (anchor_ref "IC1")
      (pad "36")
    )
    (thermal_via_array
      (name "thermal_136")
      (anchor_ref "IC1")
      (pad "37")
    )
    (thermal_via_array
      (name "thermal_137")
      (anchor_ref "IC1")
      (pad "38")
    )
    (thermal_via_array
      (name "thermal_138")
      (anchor_ref "IC1")
      (pad "39")
    )
    (thermal_via_array
      (name "thermal_139")
      (anchor_ref "IC1")
      (pad "40")
    )
    (thermal_via_array
      (name "thermal_140")
      (anchor_ref "IC1")
      (pad "41")
    )
    (thermal_via_array
      (name "thermal_141")
      (anchor_ref "IC1")
      (pad "42")
    )
    (thermal_via_array
      (name "thermal_142")
      (anchor_ref "IC1")
      (pad "43")
    )
    (thermal_via_array
      (name "thermal_143")
      (anchor_ref "IC1")
      (pad "44")
    )
    (thermal_via_array
      (name "thermal_144")
      (anchor_ref "IC1")
      (pad "45")
    )
    (thermal_via_array
      (name "thermal_145")
      (anchor_ref "IC1")
      (pad "46")
    )
    (thermal_via_array
      (name "thermal_146")
      (anchor_ref "IC1")
      (pad "47")
    )
    (thermal_via_array
      (name "thermal_147")
      (anchor_ref "IC1")
      (pad "48")
    )
    (thermal_via_array
      (name "thermal_148")
      (anchor_ref "IC1")
      (pad "49")
    )
    (thermal_via_array
      (name "thermal_149")
      (anchor_ref "IC1")
      (pad "50")
    )
    (thermal_via_array
      (name "thermal_150")
      (anchor_ref "IC1")
      (pad "51")
    )
    (thermal_via_array
      (name "thermal_151")
      (anchor_ref "IC1")
      (pad "52")
    )
    (thermal_via_array
      (name "thermal_152")
      (anchor_ref "IC1")
      (pad "53")
    )
    (thermal_via_array
      (name "thermal_153")
      (anchor_ref "IC1")
      (pad "54")
    )
    (thermal_via_array
      (name "thermal_154")
      (anchor_ref "IC1")
      (pad "55")
    )
    (thermal_via_array
      (name "thermal_155")
      (anchor_ref "IC1")
      (pad "56")
    )
    (thermal_via_array
      (name "thermal_156")
      (anchor_ref "IC1")
      (pad "57")
    )
    (thermal_via_array
      (name "thermal_157")
      (anchor_ref "IC1")
      (pad "58")
    )
    (thermal_via_array
      (name "thermal_158")
      (anchor_ref "IC1")
      (pad "59")
    )
    (thermal_via_array
      (name "thermal_159")
      (anchor_ref "IC1")
      (pad "60")
    )
    (thermal_via_array
      (name "thermal_160")
      (anchor_ref "IC1")
      (pad "61")
    )
    (thermal_via_array
      (name "thermal_161")
      (anchor_ref "IC1")
      (pad "62")
    )
    (thermal_via_array
      (name "thermal_162")
      (anchor_ref "IC1")
      (pad "63")
    )
    (thermal_via_array
      (name "thermal_163")
      (anchor_ref "IC1")
      (pad "64")
    )
    (thermal_via_array
      (name "thermal_164")
      (anchor_ref "IC1")
      (pad "65")
    )
    (thermal_via_array
      (name "thermal_165")
      (anchor_ref "IC1")
      (pad "66")
    )
    (thermal_via_array
      (name "thermal_166")
      (anchor_ref "IC1")
      (pad "67")
    )
    (thermal_via_array
      (name "thermal_167")
      (anchor_ref "IC1")
      (pad "68")
    )
    (thermal_via_array
      (name "thermal_168")
      (anchor_ref "IC1")
      (pad "69")
    )
    (thermal_via_array
      (name "thermal_169")
      (anchor_ref "IC1")
      (pad "70")
    )
    (thermal_via_array
      (name "thermal_170")
      (anchor_ref "IC1")
      (pad "71")
    )
    (thermal_via_array
      (name "thermal_171")
      (anchor_ref "IC1")
      (pad "72")
    )
    (thermal_via_array
      (name "thermal_172")
      (anchor_ref "IC1")
      (pad "73")
    )
    (thermal_via_array
      (name "thermal_173")
      (anchor_ref "IC1")
      (pad "74")
    )
    (thermal_via_array
      (name "thermal_174")
      (anchor_ref "IC1")
      (pad "75")
    )
    (thermal_via_array
      (name "thermal_175")
      (anchor_ref "IC1")
      (pad "76")
    )
    (thermal_via_array
      (name "thermal_176")
      (anchor_ref "IC1")
      (pad "77")
    )
    (thermal_via_array
      (name "thermal_177")
      (anchor_ref "IC1")
      (pad "78")
    )
    (thermal_via_array
      (name "thermal_178")
      (anchor_ref "IC1")
      (pad "79")
    )
    (thermal_via_array
      (name "thermal_179")
      (anchor_ref "IC1")
      (pad "80")
    )
    (thermal_via_array
      (name "thermal_180")
      (anchor_ref "IC1")
      (pad "81")
    )
    (thermal_via_array
      (name "thermal_181")
      (anchor_ref "IC1")
      (pad "82")
    )
    (thermal_via_array
      (name "thermal_182")
      (anchor_ref "IC1")
      (pad "83")
    )
    (thermal_via_array
      (name "thermal_183")
      (anchor_ref "IC1")
      (pad "84")
    )
    (thermal_via_array
      (name "thermal_184")
      (anchor_ref "IC1")
      (pad "85")
    )
    (thermal_via_array
      (name "thermal_185")
      (anchor_ref "IC1")
      (pad "86")
    )
    (thermal_via_array
      (name "thermal_186")
      (anchor_ref "IC1")
      (pad "87")
    )
    (thermal_via_array
      (name "thermal_187")
      (anchor_ref "IC1")
      (pad "88")
    )
    (thermal_via_array
      (name "thermal_188")
      (anchor_ref "IC1")
      (pad "89")
    )
    (thermal_via_array
      (name "thermal_189")
      (anchor_ref "IC1")
      (pad "90")
    )
    (thermal_via_array
      (name "thermal_190")
      (anchor_ref "IC1")
      (pad "91")
    )
    (thermal_via_array
      (name "thermal_191")
      (anchor_ref "IC1")
      (pad "92")
    )
    (thermal_via_array
      (name "thermal_192")
      (anchor_ref "IC1")
      (pad "93")
    )
    (thermal_via_array
      (name "thermal_193")
      (anchor_ref "IC1")
      (pad "94")
    )
    (thermal_via_array
      (name "thermal_194")
      (anchor_ref "IC1")
      (pad "95")
    )
    (thermal_via_array
      (name "thermal_195")
      (anchor_ref "IC1")
      (pad "96")
    )
    (thermal_via_array
      (name "thermal_196")
      (anchor_ref "IC1")
      (pad "97")
    )
    (thermal_via_array
      (name "thermal_197")
      (anchor_ref "IC1")
      (pad "98")
    )
    (thermal_via_array
      (name "thermal_198")
      (anchor_ref "IC1")
      (pad "99")
    )
    (thermal_via_array
      (name "thermal_199")
      (anchor_ref "IC1")
      (pad "100")
    )
  )
  (schematic_dir "../../../../KiCad/3CH-AWG-TIA/3CH-AWG-TIA-v102")
  (entities
    (entity
      (name "clone_0")
      (cell "cell_0")
      (cluster "CL_0")
    )
    (entity
      (name "clone_1")
      (cell "cell_1")
      (cluster "CL_1")
    )
    (entity
      (name "clone_2")
      (cell "cell_2")
      (cluster "CL_2")
    )
    (entity
      (name "clone_3")
      (cell "cell_3")
      (cluster "CL_3")
    )
    (entity
      (name "clone_4")
      (cell "cell_4")
      (cluster "CL_4")
    )
    (entity
      (name "clone_5")
      (cell "cell_5")
      (cluster "CL_5")
    )
    (entity
      (name "clone_6")
      (cell "cell_6")
      (cluster "CL_6")
    )
    (entity
      (name "clone_7")
      (cell "cell_7")
      (cluster "CL_7")
    )
    (entity
      (name "clone_8")
      (cell "cell_8")
      (cluster "CL_8")
    )
    (entity
      (name "clone_9")
      (cell "cell_9")
      (cluster "CL_9")
    )
    (entity
      (name "clone_10")
      (cell "cell_10")
      (cluster "CL_10")
    )
    (entity
      (name "clone_11")
      (cell "cell_11")
      (cluster "CL_11")
    )
    (entity
      (name "clone_12")
      (cell "cell_12")
      (cluster "CL_12")
    )
    (entity
      (name "clone_13")
      (cell "cell_13")
      (cluster "CL_13")
    )
    (entity
      (name "clone_14")
      (cell "cell_14")
      (cluster "CL_14")
    )
    (entity
      (name "clone_15")
      (cell "cell_15")
      (cluster "CL_15")
    )
    (entity
      (name "clone_16")
      (cell "cell_16")
      (cluster "CL_16")
    )
    (entity
      (name "clone_17")
      (cell "cell_17")
      (cluster "CL_17")
    )
    (entity
      (name "clone_18")
      (cell "cell_18")
      (cluster "CL_18")
    )
    (entity
      (name "clone_19")
      (cell "cell_19")
      (cluster "CL_19")
    )
    (entity
      (name "clone_20")
      (cell "cell_20")
      (cluster "CL_20")
    )
    (entity
      (name "clone_21")
      (cell "cell_21")
      (cluster "CL_21")
    )
    (entity
      (name "clone_22")
      (cell "cell_22")
      (cluster "CL_22")
    )
    (entity
      (name "clone_23")
      (cell "cell_23")
      (cluster "CL_23")
    )
    (entity
      (name "clone_24")
      (cell "cell_24")
      (cluster "CL_24")
    )
    (entity
      (name "clone_25")
      (cell "cell_25")
      (cluster "CL_25")
    )
    (entity
      (name "clone_26")
      (cell "cell_26")
      (cluster "CL_26")
    )
    (entity
      (name "clone_27")
      (cell "cell_27")
      (cluster "CL_27")
    )
    (entity
      (name "clone_28")
      (cell "cell_28")
      (cluster "CL_28")
    )
    (entity
      (name "clone_29")
      (cell "cell_29")
      (cluster "CL_29")
    )
    (entity
      (name "clone_30")
      (cell "cell_30")
      (cluster "CL_30")
    )
    (entity
      (name "clone_31")
      (cell "cell_31")
      (cluster "CL_31")
    )
    (entity
      (name "clone_32")
      (cell "cell_32")
      (cluster "CL_32")
    )
    (entity
      (name "clone_33")
      (cell "cell_33")
      (cluster "CL_33")
    )
    (entity
      (name "clone_34")
      (cell "cell_34")
      (cluster "CL_34")
    )
    (entity
      (name "clone_35")
      (cell "cell_35")
      (cluster "CL_35")
    )
    (entity
      (name "clone_36")
      (cell "cell_36")
      (cluster "CL_36")
    )
    (entity
      (name "clone_37")
      (cell "cell_37")
      (cluster "CL_37")
    )
    (entity
      (name "clone_38")
      (cell "cell_38")
      (cluster "CL_38")
    )
    (entity
      (name "clone_39")
      (cell "cell_39")
      (cluster "CL_39")
    )
    (entity
      (name "clone_40")
      (cell "cell_40")
      (cluster "CL_40")
    )
    (entity
      (name "clone_41")
      (cell "cell_41")
      (cluster "CL_41")
    )
    (entity
      (name "clone_42")
      (cell "cell_42")
      (cluster "CL_42")
    )
    (entity
      (name "clone_43")
      (cell "cell_43")
      (cluster "CL_43")
    )
    (entity
      (name "clone_44")
      (cell "cell_44")
      (cluster "CL_44")
    )
    (entity
      (name "clone_45")
      (cell "cell_45")
      (cluster "CL_45")
    )
    (entity
      (name "clone_46")
      (cell "cell_46")
      (cluster "CL_46")
    )
    (entity
      (name "clone_47")
      (cell "cell_47")
      (cluster "CL_47")
    )
    (entity
      (name "clone_48")
      (cell "cell_48")
      (cluster "CL_48")
    )
    (entity
      (name "clone_49")
      (cell "cell_49")
      (cluster "CL_49")
    )
    (entity
      (name "clone_50")
      (cell "cell_50")
      (cluster "CL_50")
    )
    (entity
      (name "clone_51")
      (cell "cell_51")
      (cluster "CL_51")
    )
    (entity
      (name "clone_52")
      (cell "cell_52")
      (cluster "CL_52")
    )
    (entity
      (name "clone_53")
      (cell "cell_53")
      (cluster "CL_53")
    )
    (entity
      (name "clone_54")
      (cell "cell_54")
      (cluster "CL_54")
    )
    (entity
      (name "clone_55")
      (cell "cell_55")
      (cluster "CL_55")
    )
    (entity
      (name "clone_56")
      (cell "cell_56")
      (cluster "CL_56")
    )
    (entity
      (name "clone_57")
      (cell "cell_57")
      (cluster "CL_57")
    )
    (entity
      (name "clone_58")
      (cell "cell_58")
      (cluster "CL_58")
    )
    (entity
      (name "clone_59")
      (cell "cell_59")
      (cluster "CL_59")
    )
    (entity
      (name "clone_60")
      (cell "cell_60")
      (cluster "CL_60")
    )
    (entity
      (name "clone_61")
      (cell "cell_61")
      (cluster "CL_61")
    )
    (entity
      (name "clone_62")
      (cell "cell_62")
      (cluster "CL_62")
    )
    (entity
      (name "clone_63")
      (cell "cell_63")
      (cluster "CL_63")
    )
    (entity
      (name "clone_64")
      (cell "cell_64")
      (cluster "CL_64")
    )
    (entity
      (name "clone_65")
      (cell "cell_65")
      (cluster "CL_65")
    )
    (entity
      (name "clone_66")
      (cell "cell_66")
      (cluster "CL_66")
    )
    (entity
      (name "clone_67")
      (cell "cell_67")
      (cluster "CL_67")
    )
    (entity
      (name "clone_68")
      (cell "cell_68")
      (cluster "CL_68")
    )
    (entity
      (name "clone_69")
      (cell "cell_69")
      (cluster "CL_69")
    )
    (entity
      (name "clone_70")
      (cell "cell_70")
      (cluster "CL_70")
    )
    (entity
      (name "clone_71")
      (cell "cell_71")
      (cluster "CL_71")
    )
    (entity
      (name "clone_72")
      (cell "cell_72")
      (cluster "CL_72")
    )
    (entity
      (name "clone_73")
      (cell "cell_73")
      (cluster "CL_73")
    )
    (entity
      (name "clone_74")
      (cell "cell_74")
      (cluster "CL_74")
    )
    (entity
      (name "clone_75")
      (cell "cell_75")
      (cluster "CL_75")
    )
    (entity
      (name "clone_76")
      (cell "cell_76")
      (cluster "CL_76")
    )
    (entity
      (name "clone_77")
      (cell "cell_77")
      (cluster "CL_77")
    )
    (entity
      (name "clone_78")
      (cell "cell_78")
      (cluster "CL_78")
    )
    (entity
      (name "clone_79")
      (cell "cell_79")
      (cluster "CL_79")
    )
    (entity
      (name "clone_80")
      (cell "cell_0")
      (cluster "CL_80")
    )
    (entity
      (name "clone_81")
      (cell "cell_1")
      (cluster "CL_81")
    )
    (entity
      (name "clone_82")
      (cell "cell_2")
      (cluster "CL_82")
    )
    (entity
      (name "clone_83")
      (cell "cell_3")
      (cluster "CL_83")
    )
    (entity
      (name "clone_84")
      (cell "cell_4")
      (cluster "CL_84")
    )
    (entity
      (name "clone_85")
      (cell "cell_5")
      (cluster "CL_85")
    )
    (entity
      (name "clone_86")
      (cell "cell_6")
      (cluster "CL_86")
    )
    (entity
      (name "clone_87")
      (cell "cell_7")
      (cluster "CL_87")
    )
    (entity
      (name "clone_88")
      (cell "cell_8")
      (cluster "CL_88")
    )
    (entity
      (name "clone_89")
      (cell "cell_9")
      (cluster "CL_89")
    )
    (entity
      (name "clone_90")
      (cell "cell_10")
      (cluster "CL_90")
    )
    (entity
      (name "clone_91")
      (cell "cell_11")
      (cluster "CL_91")
    )
    (entity
      (name "clone_92")
      (cell "cell_12")
      (cluster "CL_92")
    )
    (entity
      (name "clone_93")
      (cell "cell_13")
      (cluster "CL_93")
    )
    (entity
      (name "clone_94")
      (cell "cell_14")
      (cluster "CL_94")
    )
    (entity
      (name "clone_95")
      (cell "cell_15")
      (cluster "CL_95")
    )
    (entity
      (name "clone_96")
      (cell "cell_16")
      (cluster "CL_96")
    )
    (entity
      (name "clone_97")
      (cell "cell_17")
      (cluster "CL_97")
    )
    (entity
      (name "clone_98")
      (cell "cell_18")
      (cluster "CL_98")
    )
    (entity
      (name "clone_99")
      (cell "cell_19")
      (cluster "CL_99")
    )
    (entity
      (name "clone_100")
      (cell "cell_20")
      (cluster "CL_100")
    )
    (entity
      (name "clone_101")
      (cell "cell_21")
      (cluster "CL_101")
    )
    (entity
      (name "clone_102")
      (cell "cell_22")
      (cluster "CL_102")
    )
    (entity
      (name "clone_103")
      (cell "cell_23")
      (cluster "CL_103")
    )
    (entity
      (name "clone_104")
      (cell "cell_24")
      (cluster "CL_104")
    )
    (entity
      (name "clone_105")
      (cell "cell_25")
      (cluster "CL_105")
    )
    (entity
      (name "clone_106")
      (cell "cell_26")
      (cluster "CL_106")
    )
    (entity
      (name "clone_107")
      (cell "cell_27")
      (cluster "CL_107")
    )
    (entity
      (name "clone_108")
      (cell "cell_28")
      (cluster "CL_108")
    )
    (entity
      (name "clone_109")
      (cell "cell_29")
      (cluster "CL_109")
    )
    (entity
      (name "clone_110")
      (cell "cell_30")
      (cluster "CL_110")
    )
    (entity
      (name "clone_111")
      (cell "cell_31")
      (cluster "CL_111")
    )
    (entity
      (name "clone_112")
      (cell "cell_32")
      (cluster "CL_112")
    )
    (entity
      (name "clone_113")
      (cell "cell_33")
      (cluster "CL_113")
    )
    (entity
      (name "clone_114")
      (cell "cell_34")
      (cluster "CL_114")
    )
    (entity
      (name "clone_115")
      (cell "cell_35")
      (cluster "CL_115")
    )
    (entity
      (name "clone_116")
      (cell "cell_36")
      (cluster "CL_116")
    )
    (entity
      (name "clone_117")
      (cell "cell_37")
      (cluster "CL_117")
    )
    (entity
      (name "clone_118")
      (cell "cell_38")
      (cluster "CL_118")
    )
    (entity
      (name "clone_119")
      (cell "cell_39")
      (cluster "CL_119")
    )
    (entity
      (name "clone_120")
      (cell "cell_40")
      (cluster "CL_120")
    )
    (entity
      (name "clone_121")
      (cell "cell_41")
      (cluster "CL_121")
    )
    (entity
      (name "clone_122")
      (cell "cell_42")
      (cluster "CL_122")
    )
    (entity
      (name "clone_123")
      (cell "cell_43")
      (cluster "CL_123")
    )
    (entity
      (name "clone_124")
      (cell "cell_44")
      (cluster "CL_124")
    )
    (entity
      (name "clone_125")
      (cell "cell_45")
      (cluster "CL_125")
    )
    (entity
      (name "clone_126")
      (cell "cell_46")
      (cluster "CL_126")
    )
    (entity
      (name "clone_127")
      (cell "cell_47")
      (cluster "CL_127")
    )
    (entity
      (name "clone_128")
      (cell "cell_48")
      (cluster "CL_128")
    )
    (entity
      (name "clone_129")
      (cell "cell_49")
      (cluster "CL_129")
    )
    (entity
      (name "clone_130")
      (cell "cell_50")
      (cluster "CL_130")
    )
    (entity
      (name "clone_131")
      (cell "cell_51")
      (cluster "CL_131")
    )
    (entity
      (name "clone_132")
      (cell "cell_52")
      (cluster "CL_132")
    )
    (entity
      (name "clone_133")
      (cell "cell_53")
      (cluster "CL_133")
    )
    (entity
      (name "clone_134")
      (cell "cell_54")
      (cluster "CL_134")
    )
    (entity
      (name "clone_135")
      (cell "cell_55")
      (cluster "CL_135")
    )
    (entity
      (name "clone_136")
      (cell "cell_56")
      (cluster "CL_136")
    )
    (entity
      (name "clone_137")
      (cell "cell_57")
      (cluster "CL_137")
    )
    (entity
      (name "clone_138")
      (cell "cell_58")
      (cluster "CL_138")
    )
    (entity
      (name "clone_139")
      (cell "cell_59")
      (cluster "CL_139")
    )
    (entity
      (name "clone_140")
      (cell "cell_60")
      (cluster "CL_140")
    )
    (entity
      (name "clone_141")
      (cell "cell_61")
      (cluster "CL_141")
    )
    (entity
      (name "clone_142")
      (cell "cell_62")
      (cluster "CL_142")
    )
    (entity
      (name "clone_143")
      (cell "cell_63")
      (cluster "CL_143")
    )
    (entity
      (name "clone_144")
      (cell "cell_64")
      (cluster "CL_144")
    )
    (entity
      (name "clone_145")
      (cell "cell_65")
      (cluster "CL_145")
    )
    (entity
      (name "clone_146")
      (cell "cell_66")
      (cluster "CL_146")
    )
    (entity
      (name "clone_147")
      (cell "cell_67")
      (cluster "CL_147")
    )
    (entity
      (name "clone_148")
      (cell "cell_68")
      (cluster "CL_148")
    )
    (entity
      (name "clone_149")
      (cell "cell_69")
      (cluster "CL_149")
    )
    (entity
      (name "clone_150")
      (cell "cell_70")
      (cluster "CL_150")
    )
    (entity
      (name "clone_151")
      (cell "cell_71")
      (cluster "CL_151")
    )
    (entity
      (name "clone_152")
      (cell "cell_72")
      (cluster "CL_152")
    )
    (entity
      (name "clone_153")
      (cell "cell_73")
      (cluster "CL_153")
    )
    (entity
      (name "clone_154")
      (cell "cell_74")
      (cluster "CL_154")
    )
    (entity
      (name "clone_155")
      (cell "cell_75")
      (cluster "CL_155")
    )
    (entity
      (name "clone_156")
      (cell "cell_76")
      (cluster "CL_156")
    )
    (entity
      (name "clone_157")
      (cell "cell_77")
      (cluster "CL_157")
    )
    (entity
      (name "clone_158")
      (cell "cell_78")
      (cluster "CL_158")
    )
    (entity
      (name "clone_159")
      (cell "cell_79")
      (cluster "CL_159")
    )
    (entity
      (name "clone_160")
      (cell "cell_0")
      (cluster "CL_160")
    )
    (entity
      (name "clone_161")
      (cell "cell_1")
      (cluster "CL_161")
    )
    (entity
      (name "clone_162")
      (cell "cell_2")
      (cluster "CL_162")
    )
    (entity
      (name "clone_163")
      (cell "cell_3")
      (cluster "CL_163")
    )
    (entity
      (name "clone_164")
      (cell "cell_4")
      (cluster "CL_164")
    )
    (entity
      (name "clone_165")
      (cell "cell_5")
      (cluster "CL_165")
    )
    (entity
      (name "clone_166")
      (cell "cell_6")
      (cluster "CL_166")
    )
    (entity
      (name "clone_167")
      (cell "cell_7")
      (cluster "CL_167")
    )
    (entity
      (name "clone_168")
      (cell "cell_8")
      (cluster "CL_168")
    )
    (entity
      (name "clone_169")
      (cell "cell_9")
      (cluster "CL_169")
    )
    (entity
      (name "clone_170")
      (cell "cell_10")
      (cluster "CL_170")
    )
    (entity
      (name "clone_171")
      (cell "cell_11")
      (cluster "CL_171")
    )
    (entity
      (name "clone_172")
      (cell "cell_12")
      (cluster "CL_172")
    )
    (entity
      (name "clone_173")
      (cell "cell_13")
      (cluster "CL_173")
    )
    (entity
      (name "clone_174")
      (cell "cell_14")
      (cluster "CL_174")
    )
    (entity
      (name "clone_175")
      (cell "cell_15")
      (cluster "CL_175")
    )
    (entity
      (name "clone_176")
      (cell "cell_16")
      (cluster "CL_176")
    )
    (entity
      (name "clone_177")
      (cell "cell_17")
      (cluster "CL_177")
    )
    (entity
      (name "clone_178")
      (cell "cell_18")
      (cluster "CL_178")
    )
    (entity
      (name "clone_179")
      (cell "cell_19")
      (cluster "CL_179")
    )
    (entity
      (name "clone_180")
      (cell "cell_20")
      (cluster "CL_180")
    )
    (entity
      (name "clone_181")
      (cell "cell_21")
      (cluster "CL_181")
    )
    (entity
      (name "clone_182")
      (cell "cell_22")
      (cluster "CL_182")
    )
    (entity
      (name "clone_183")
      (cell "cell_23")
      (cluster "CL_183")
    )
    (entity
      (name "clone_184")
      (cell "cell_24")
      (cluster "CL_184")
    )
    (entity
      (name "clone_185")
      (cell "cell_25")
      (cluster "CL_185")
    )
    (entity
      (name "clone_186")
      (cell "cell_26")
      (cluster "CL_186")
    )
    (entity
      (name "clone_187")
      (cell "cell_27")
      (cluster "CL_187")
    )
    (entity
      (name "clone_188")
      (cell "cell_28")
      (cluster "CL_188")
    )
    (entity
      (name "clone_189")
      (cell "cell_29")
      (cluster "CL_189")
    )
    (entity
      (name "clone_190")
      (cell "cell_30")
      (cluster "CL_190")
    )
    (entity
      (name "clone_191")
      (cell "cell_31")
      (cluster "CL_191")
    )
    (entity
      (name "clone_192")
      (cell "cell_32")
      (cluster "CL_192")
    )
    (entity
      (name "clone_193")
      (cell "cell_33")
      (cluster "CL_193")
    )
    (entity
      (name "clone_194")
      (cell "cell_34")
      (cluster "CL_194")
    )
    (entity
      (name "clone_195")
      (cell "cell_35")
      (cluster "CL_195")
    )
    (entity
      (name "clone_196")
      (cell "cell_36")
      (cluster "CL_196")
    )
    (entity
      (name "clone_197")
      (cell "cell_37")
      (cluster "CL_197")
    )
    (entity
      (name "clone_198")
      (cell "cell_38")
      (cluster "CL_198")
    )
    (entity
      (name "clone_199")
      (cell "cell_39")
      (cluster "CL_199")
    )
    (entity
      (name "clone_200")
      (cell "cell_40")
      (cluster "CL_200")
    )
    (entity
      (name "clone_201")
      (cell "cell_41")
      (cluster "CL_201")
    )
    (entity
      (name "clone_202")
      (cell "cell_42")
      (cluster "CL_202")
    )
    (entity
      (name "clone_203")
      (cell "cell_43")
      (cluster "CL_203")
    )
    (entity
      (name "clone_204")
      (cell "cell_44")
      (cluster "CL_204")
    )
    (entity
      (name "clone_205")
      (cell "cell_45")
      (cluster "CL_205")
    )
    (entity
      (name "clone_206")
      (cell "cell_46")
      (cluster "CL_206")
    )
    (entity
      (name "clone_207")
      (cell "cell_47")
      (cluster "CL_207")
    )
    (entity
      (name "clone_208")
      (cell "cell_48")
      (cluster "CL_208")
    )
    (entity
      (name "clone_209")
      (cell "cell_49")
      (cluster "CL_209")
    )
    (entity
      (name "clone_210")
      (cell "cell_50")
      (cluster "CL_210")
    )
    (entity
      (name "clone_211")
      (cell "cell_51")
      (cluster "CL_211")
    )
    (entity
      (name "clone_212")
      (cell "cell_52")
      (cluster "CL_212")
    )
    (entity
      (name "clone_213")
      (cell "cell_53")
      (cluster "CL_213")
    )
    (entity
      (name "clone_214")
      (cell "cell_54")
      (cluster "CL_214")
    )
    (entity
      (name "clone_215")
      (cell "cell_55")
      (cluster "CL_215")
    )
    (entity
      (name "clone_216")
      (cell "cell_56")
      (cluster "CL_216")
    )
    (entity
      (name "clone_217")
      (cell "cell_57")
      (cluster "CL_217")
    )
    (entity
      (name "clone_218")
      (cell "cell_58")
      (cluster "CL_218")
    )
    (entity
      (name "clone_219")
      (cell "cell_59")
      (cluster "CL_219")
    )
    (entity
      (name "clone_220")
      (cell "cell_60")
      (cluster "CL_220")
    )
    (entity
      (name "clone_221")
      (cell "cell_61")
      (cluster "CL_221")
    )
    (entity
      (name "clone_222")
      (cell "cell_62")
      (cluster "CL_222")
    )
    (entity
      (name "clone_223")
      (cell "cell_63")
      (cluster "CL_223")
    )
    (entity
      (name "clone_224")
      (cell "cell_64")
      (cluster "CL_224")
    )
    (entity
      (name "clone_225")
      (cell "cell_65")
      (cluster "CL_225")
    )
    (entity
      (name "clone_226")
      (cell "cell_66")
      (cluster "CL_226")
    )
    (entity
      (name "clone_227")
      (cell "cell_67")
      (cluster "CL_227")
    )
    (entity
      (name "clone_228")
      (cell "cell_68")
      (cluster "CL_228")
    )
    (entity
      (name "clone_229")
      (cell "cell_69")
      (cluster "CL_229")
    )
    (entity
      (name "clone_230")
      (cell "cell_70")
      (cluster "CL_230")
    )
    (entity
      (name "clone_231")
      (cell "cell_71")
      (cluster "CL_231")
    )
    (entity
      (name "clone_232")
      (cell "cell_72")
      (cluster "CL_232")
    )
    (entity
      (name "clone_233")
      (cell "cell_73")
      (cluster "CL_233")
    )
    (entity
      (name "clone_234")
      (cell "cell_74")
      (cluster "CL_234")
    )
    (entity
      (name "clone_235")
      (cell "cell_75")
      (cluster "CL_235")
    )
    (entity
      (name "clone_236")
      (cell "cell_76")
      (cluster "CL_236")
    )
    (entity
      (name "clone_237")
      (cell "cell_77")
      (cluster "CL_237")
    )
    (entity
      (name "clone_238")
      (cell "cell_78")
      (cluster "CL_238")
    )
    (entity
      (name "clone_239")
      (cell "cell_79")
      (cluster "CL_239")
    )
    (entity
      (name "clone_240")
      (cell "cell_0")
      (cluster "CL_240")
    )
    (entity
      (name "clone_241")
      (cell "cell_1")
      (cluster "CL_241")
    )
    (entity
      (name "clone_242")
      (cell "cell_2")
      (cluster "CL_242")
    )
    (entity
      (name "clone_243")
      (cell "cell_3")
      (cluster "CL_243")
    )
    (entity
      (name "clone_244")
      (cell "cell_4")
      (cluster "CL_244")
    )
    (entity
      (name "clone_245")
      (cell "cell_5")
      (cluster "CL_245")
    )
    (entity
      (name "clone_246")
      (cell "cell_6")
      (cluster "CL_246")
    )
    (entity
      (name "clone_247")
      (cell "cell_7")
      (cluster "CL_247")
    )
    (entity
      (name "clone_248")
      (cell "cell_8")
      (cluster "CL_248")
    )
    (entity
      (name "clone_249")
      (cell "cell_9")
      (cluster "CL_249")
    )
    (entity
      (name "clone_250")
      (cell "cell_10")
      (cluster "CL_250")
    )
    (entity
      (name "clone_251")
      (cell "cell_11")
      (cluster "CL_251")
    )
    (entity
      (name "clone_252")
      (cell "cell_12")
      (cluster "CL_252")
    )
    (entity
      (name "clone_253")
      (cell "cell_13")
      (cluster "CL_253")
    )
    (entity
      (name "clone_254")
      (cell "cell_14")
      (cluster "CL_254")
    )
    (entity
      (name "clone_255")
      (cell "cell_15")
      (cluster "CL_255")
    )
    (entity
      (name "clone_256")
      (cell "cell_16")
      (cluster "CL_256")
    )
    (entity
      (name "clone_257")
      (cell "cell_17")
      (cluster "CL_257")
    )
    (entity
      (name "clone_258")
      (cell "cell_18")
      (cluster "CL_258")
    )
    (entity
      (name "clone_259")
      (cell "cell_19")
      (cluster "CL_259")
    )
    (entity
      (name "clone_260")
      (cell "cell_20")
      (cluster "CL_260")
    )
    (entity
      (name "clone_261")
      (cell "cell_21")
      (cluster "CL_261")
    )
    (entity
      (name "clone_262")
      (cell "cell_22")
      (cluster "CL_262")
    )
    (entity
      (name "clone_263")
      (cell "cell_23")
      (cluster "CL_263")
    )
    (entity
      (name "clone_264")
      (cell "cell_24")
      (cluster "CL_264")
    )
    (entity
      (name "clone_265")
      (cell "cell_25")
      (cluster "CL_265")
    )
    (entity
      (name "clone_266")
      (cell "cell_26")
      (cluster "CL_266")
    )
    (entity
      (name "clone_267")
      (cell "cell_27")
      (cluster "CL_267")
    )
    (entity
      (name "clone_268")
      (cell "cell_28")
      (cluster "CL_268")
    )
    (entity
      (name "clone_269")
      (cell "cell_29")
      (cluster "CL_269")
    )
    (entity
      (name "clone_270")
      (cell "cell_30")
      (cluster "CL_270")
    )
    (entity
      (name "clone_271")
      (cell "cell_31")
      (cluster "CL_271")
    )
    (entity
      (name "clone_272")
      (cell "cell_32")
      (cluster "CL_272")
    )
    (entity
      (name "clone_273")
      (cell "cell_33")
      (cluster "CL_273")
    )
    (entity
      (name "clone_274")
      (cell "cell_34")
      (cluster "CL_274")
    )
    (entity
      (name "clone_275")
      (cell "cell_35")
      (cluster "CL_275")
    )
    (entity
      (name "clone_276")
      (cell "cell_36")
      (cluster "CL_276")
    )
    (entity
      (name "clone_277")
      (cell "cell_37")
      (cluster "CL_277")
    )
    (entity
      (name "clone_278")
      (cell "cell_38")
      (cluster "CL_278")
    )
    (entity
      (name "clone_279")
      (cell "cell_39")
      (cluster "CL_279")
    )
    (entity
      (name "clone_280")
      (cell "cell_40")
      (cluster "CL_280")
    )
    (entity
      (name "clone_281")
      (cell "cell_41")
      (cluster "CL_281")
    )
    (entity
      (name "clone_282")
      (cell "cell_42")
      (cluster "CL_282")
    )
    (entity
      (name "clone_283")
      (cell "cell_43")
      (cluster "CL_283")
    )
    (entity
      (name "clone_284")
      (cell "cell_44")
      (cluster "CL_284")
    )
    (entity
      (name "clone_285")
      (cell "cell_45")
      (cluster "CL_285")
    )
    (entity
      (name "clone_286")
      (cell "cell_46")
      (cluster "CL_286")
    )
    (entity
      (name "clone_287")
      (cell "cell_47")
      (cluster "CL_287")
    )
    (entity
      (name "clone_288")
      (cell "cell_48")
      (cluster "CL_288")
    )
    (entity
      (name "clone_289")
      (cell "cell_49")
      (cluster "CL_289")
    )
    (entity
      (name "clone_290")
      (cell "cell_50")
      (cluster "CL_290")
    )
    (entity
      (name "clone_291")
      (cell "cell_51")
      (cluster "CL_291")
    )
    (entity
      (name "clone_292")
      (cell "cell_52")
      (cluster "CL_292")
    )
    (entity
      (name "clone_293")
      (cell "cell_53")
      (cluster "CL_293")
    )
    (entity
      (name "clone_294")
      (cell "cell_54")
      (cluster "CL_294")
    )
    (entity
      (name "clone_295")
      (cell "cell_55")
      (cluster "CL_295")
    )
    (entity
      (name "clone_296")
      (cell "cell_56")
      (cluster "CL_296")
    )
    (entity
      (name "clone_297")
      (cell "cell_57")
      (cluster "CL_297")
    )
    (entity
      (name "clone_298")
      (cell "cell_58")
      (cluster "CL_298")
    )
    (entity
      (name "clone_299")
      (cell "cell_59")
      (cluster "CL_299")
    )
  )
  (trees
    (tree
      (name "clone_0")
      (anchor
        (origin)
      )
      (node
        (ref "clone_0")
        (kind placement)
        (xy 0.0 0.0)
      )
    )
    (tree
      (name "clone_1")
      (anchor
        (origin)
      )
      (node
        (ref "clone_1")
        (kind placement)
        (xy 1.0 0.0)
      )
    )
    (tree
      (name "clone_2")
      (anchor
        (origin)
      )
      (node
        (ref "clone_2")
        (kind placement)
        (xy 2.0 0.0)
      )
    )
    (tree
      (name "clone_3")
      (anchor
        (origin)
      )
      (node
        (ref "clone_3")
        (kind placement)
        (xy 3.0 0.0)
      )
    )
    (tree
      (name "clone_4")
      (anchor
        (origin)
      )
      (node
        (ref "clone_4")
        (kind placement)
        (xy 4.0 0.0)
      )
    )
    (tree
      (name "clone_5")
      (anchor
        (origin)
      )
      (node
        (ref "clone_5")
        (kind placement)
        (xy 5.0 0.0)
      )
    )
    (tree
      (name "clone_6")
      (anchor
        (origin)
      )
      (node
        (ref "clone_6")
        (kind placement)
        (xy 6.0 0.0)
      )
    )
    (tree
      (name "clone_7")
      (anchor
        (origin)
      )
      (node
        (ref "clone_7")
        (kind placement)
        (xy 7.0 0.0)
      )
    )
    (tree
      (name "clone_8")
      (anchor
        (origin)
      )
      (node
        (ref "clone_8")
        (kind placement)
        (xy 8.0 0.0)
      )
    )
    (tree
      (name "clone_9")
      (anchor
        (origin)
      )
      (node
        (ref "clone_9")
        (kind placement)
        (xy 9.0 0.0)
      )
    )
    (tree
      (name "clone_10")
      (anchor
        (origin)
      )
      (node
        (ref "clone_10")
        (kind placement)
        (xy 10.0 0.0)
      )
    )
    (tree
      (name "clone_11")
      (anchor
        (origin)
      )
      (node
        (ref "clone_11")
        (kind placement)
        (xy 11.0 0.0)
      )
    )
    (tree
      (name "clone_12")
      (anchor
        (origin)
      )
      (node
        (ref "clone_12")
        (kind placement)
        (xy 12.0 0.0)
      )
    )
    (tree
      (name "clone_13")
      (anchor
        (origin)
      )
      (node
        (ref "clone_13")
        (kind placement)
        (xy 13.0 0.0)
      )
    )
    (tree
      (name "clone_14")
      (anchor
        (origin)
      )
      (node
        (ref "clone_14")
        (kind placement)
        (xy 14.0 0.0)
      )
    )
    (tree
      (name "clone_15")
      (anchor
        (origin)
      )
      (node
        (ref "clone_15")
        (kind placement)
        (xy 15.0 0.0)
      )
    )
    (tree
      (name "clone_16")
      (anchor
        (origin)
      )
      (node
        (ref "clone_16")
        (kind placement)
        (xy 16.0 0.0)
      )
    )
    (tree
      (name "clone_17")
      (anchor
        (origin)
      )
      (node
        (ref "clone_17")
        (kind placement)
        (xy 17.0 0.0)
      )
    )
    (tree
      (name "clone_18")
      (anchor
        (origin)
      )
      (node
        (ref "clone_18")
        (kind placement)
        (xy 18.0 0.0)
      )
    )
    (tree
      (name "clone_19")
      (anchor
        (origin)
      )
      (node
        (ref "clone_19")
        (kind placement)
        (xy 19.0 0.0)
      )
    )
    (tree
      (name "clone_20")
      (anchor
        (origin)
      )
      (node
        (ref "clone_20")
        (kind placement)
        (xy 20.0 0.0)
      )
    )
    (tree
      (name "clone_21")
      (anchor
        (origin)
      )
      (node
        (ref "clone_21")
        (kind placement)
        (xy 21.0 0.0)
      )
    )
    (tree
      (name "clone_22")
      (anchor
        (origin)
      )
      (node
        (ref "clone_22")
        (kind placement)
        (xy 22.0 0.0)
      )
    )
    (tree
      (name "clone_23")
      (anchor
        (origin)
      )
      (node
        (ref "clone_23")
        (kind placement)
        (xy 23.0 0.0)
      )
    )
    (tree
      (name "clone_24")
      (anchor
        (origin)
      )
      (node
        (ref "clone_24")
        (kind placement)
        (xy 24.0 0.0)
      )
    )
    (tree
      (name "clone_25")
      (anchor
        (origin)
      )
      (node
        (ref "clone_25")
        (kind placement)
        (xy 25.0 0.0)
      )
    )
    (tree
      (name "clone_26")
      (anchor
        (origin)
      )
      (node
        (ref "clone_26")
        (kind placement)
        (xy 26.0 0.0)
      )
    )
    (tree
      (name "clone_27")
      (anchor
        (origin)
      )
      (node
        (ref "clone_27")
        (kind placement)
        (xy 27.0 0.0)
      )
    )
    (tree
      (name "clone_28")
      (anchor
        (origin)
      )
      (node
        (ref "clone_28")
        (kind placement)
        (xy 28.0 0.0)
      )
    )
    (tree
      (name "clone_29")
      (anchor
        (origin)
      )
      (node
        (ref "clone_29")
        (kind placement)
        (xy 29.0 0.0)
      )
    )
    (tree
      (name "clone_30")
      (anchor
        (origin)
      )
      (node
        (ref "clone_30")
        (kind placement)
        (xy 30.0 0.0)
      )
    )
    (tree
      (name "clone_31")
      (anchor
        (origin)
      )
      (node
        (ref "clone_31")
        (kind placement)
        (xy 31.0 0.0)
      )
    )
    (tree
      (name "clone_32")
      (anchor
        (origin)
      )
      (node
        (ref "clone_32")
        (kind placement)
        (xy 32.0 0.0)
      )
    )
    (tree
      (name "clone_33")
      (anchor
        (origin)
      )
      (node
        (ref "clone_33")
        (kind placement)
        (xy 33.0 0.0)
      )
    )
    (tree
      (name "clone_34")
      (anchor
        (origin)
      )
      (node
        (ref "clone_34")
        (kind placement)
        (xy 34.0 0.0)
      )
    )
    (tree
      (name "clone_35")
      (anchor
        (origin)
      )
      (node
        (ref "clone_35")
        (kind placement)
        (xy 35.0 0.0)
      )
    )
    (tree
      (name "clone_36")
      (anchor
        (origin)
      )
      (node
        (ref "clone_36")
        (kind placement)
        (xy 36.0 0.0)
      )
    )
    (tree
      (name "clone_37")
      (anchor
        (origin)
      )
      (node
        (ref "clone_37")
        (kind placement)
        (xy 37.0 0.0)
      )
    )
    (tree
      (name "clone_38")
      (anchor
        (origin)
      )
      (node
        (ref "clone_38")
        (kind placement)
        (xy 38.0 0.0)
      )
    )
    (tree
      (name "clone_39")
      (anchor
        (origin)
      )
      (node
        (ref "clone_39")
        (kind placement)
        (xy 39.0 0.0)
      )
    )
    (tree
      (name "clone_40")
      (anchor
        (origin)
      )
      (node
        (ref "clone_40")
        (kind placement)
        (xy 40.0 0.0)
      )
    )
    (tree
      (name "clone_41")
      (anchor
        (origin)
      )
      (node
        (ref "clone_41")
        (kind placement)
        (xy 41.0 0.0)
      )
    )
    (tree
      (name "clone_42")
      (anchor
        (origin)
      )
      (node
        (ref "clone_42")
        (kind placement)
        (xy 42.0 0.0)
      )
    )
    (tree
      (name "clone_43")
      (anchor
        (origin)
      )
      (node
        (ref "clone_43")
        (kind placement)
        (xy 43.0 0.0)
      )
    )
    (tree
      (name "clone_44")
      (anchor
        (origin)
      )
      (node
        (ref "clone_44")
        (kind placement)
        (xy 44.0 0.0)
      )
    )
    (tree
      (name "clone_45")
      (anchor
        (origin)
      )
      (node
        (ref "clone_45")
        (kind placement)
        (xy 45.0 0.0)
      )
    )
    (tree
      (name "clone_46")
      (anchor
        (origin)
      )
      (node
        (ref "clone_46")
        (kind placement)
        (xy 46.0 0.0)
      )
    )
    (tree
      (name "clone_47")
      (anchor
        (origin)
      )
      (node
        (ref "clone_47")
        (kind placement)
        (xy 47.0 0.0)
      )
    )
    (tree
      (name "clone_48")
      (anchor
        (origin)
      )
      (node
        (ref "clone_48")
        (kind placement)
        (xy 48.0 0.0)
      )
    )
    (tree
      (name "clone_49")
      (anchor
        (origin)
      )
      (node
        (ref "clone_49")
        (kind placement)
        (xy 49.0 0.0)
      )
    )
    (tree
      (name "clone_50")
      (anchor
        (origin)
      )
      (node
        (ref "clone_50")
        (kind placement)
        (xy 50.0 0.0)
      )
    )
    (tree
      (name "clone_51")
      (anchor
        (origin)
      )
      (node
        (ref "clone_51")
        (kind placement)
        (xy 51.0 0.0)
      )
    )
    (tree
      (name "clone_52")
      (anchor
        (origin)
      )
      (node
        (ref "clone_52")
        (kind placement)
        (xy 52.0 0.0)
      )
    )
    (tree
      (name "clone_53")
      (anchor
        (origin)
      )
      (node
        (ref "clone_53")
        (kind placement)
        (xy 53.0 0.0)
      )
    )
    (tree
      (name "clone_54")
      (anchor
        (origin)
      )
      (node
        (ref "clone_54")
        (kind placement)
        (xy 54.0 0.0)
      )
    )
    (tree
      (name "clone_55")
      (anchor
        (origin)
      )
      (node
        (ref "clone_55")
        (kind placement)
        (xy 55.0 0.0)
      )
    )
    (tree
      (name "clone_56")
      (anchor
        (origin)
      )
      (node
        (ref "clone_56")
        (kind placement)
        (xy 56.0 0.0)
      )
    )
    (tree
      (name "clone_57")
      (anchor
        (origin)
      )
      (node
        (ref "clone_57")
        (kind placement)
        (xy 57.0 0.0)
      )
    )
    (tree
      (name "clone_58")
      (anchor
        (origin)
      )
      (node
        (ref "clone_58")
        (kind placement)
        (xy 58.0 0.0)
      )
    )
    (tree
      (name "clone_59")
      (anchor
        (origin)
      )
      (node
        (ref "clone_59")
        (kind placement)
        (xy 59.0 0.0)
      )
    )
    (tree
      (name "clone_60")
      (anchor
        (origin)
      )
      (node
        (ref "clone_60")
        (kind placement)
        (xy 60.0 0.0)
      )
    )
    (tree
      (name "clone_61")
      (anchor
        (origin)
      )
      (node
        (ref "clone_61")
        (kind placement)
        (xy 61.0 0.0)
      )
    )
    (tree
      (name "clone_62")
      (anchor
        (origin)
      )
      (node
        (ref "clone_62")
        (kind placement)
        (xy 62.0 0.0)
      )
    )
    (tree
      (name "clone_63")
      (anchor
        (origin)
      )
      (node
        (ref "clone_63")
        (kind placement)
        (xy 63.0 0.0)
      )
    )
    (tree
      (name "clone_64")
      (anchor
        (origin)
      )
      (node
        (ref "clone_64")
        (kind placement)
        (xy 64.0 0.0)
      )
    )
    (tree
      (name "clone_65")
      (anchor
        (origin)
      )
      (node
        (ref "clone_65")
        (kind placement)
        (xy 65.0 0.0)
      )
    )
    (tree
      (name "clone_66")
      (anchor
        (origin)
      )
      (node
        (ref "clone_66")
        (kind placement)
        (xy 66.0 0.0)
      )
    )
    (tree
      (name "clone_67")
      (anchor
        (origin)
      )
      (node
        (ref "clone_67")
        (kind placement)
        (xy 67.0 0.0)
      )
    )
    (tree
      (name "clone_68")
      (anchor
        (origin)
      )
      (node
        (ref "clone_68")
        (kind placement)
        (xy 68.0 0.0)
      )
    )
    (tree
      (name "clone_69")
      (anchor
        (origin)
      )
      (node
        (ref "clone_69")
        (kind placement)
        (xy 69.0 0.0)
      )
    )
    (tree
      (name "clone_70")
      (anchor
        (origin)
      )
      (node
        (ref "clone_70")
        (kind placement)
        (xy 70.0 0.0)
      )
    )
    (tree
      (name "clone_71")
      (anchor
        (origin)
      )
      (node
        (ref "clone_71")
        (kind placement)
        (xy 71.0 0.0)
      )
    )
    (tree
      (name "clone_72")
      (anchor
        (origin)
      )
      (node
        (ref "clone_72")
        (kind placement)
        (xy 72.0 0.0)
      )
    )
    (tree
      (name "clone_73")
      (anchor
        (origin)
      )
      (node
        (ref "clone_73")
        (kind placement)
        (xy 73.0 0.0)
      )
    )
    (tree
      (name "clone_74")
      (anchor
        (origin)
      )
      (node
        (ref "clone_74")
        (kind placement)
        (xy 74.0 0.0)
      )
    )
    (tree
      (name "clone_75")
      (anchor
        (origin)
      )
      (node
        (ref "clone_75")
        (kind placement)
        (xy 75.0 0.0)
      )
    )
    (tree
      (name "clone_76")
      (anchor
        (origin)
      )
      (node
        (ref "clone_76")
        (kind placement)
        (xy 76.0 0.0)
      )
    )
    (tree
      (name "clone_77")
      (anchor
        (origin)
      )
      (node
        (ref "clone_77")
        (kind placement)
        (xy 77.0 0.0)
      )
    )
    (tree
      (name "clone_78")
      (anchor
        (origin)
      )
      (node
        (ref "clone_78")
        (kind placement)
        (xy 78.0 0.0)
      )
    )
    (tree
      (name "clone_79")
      (anchor
        (origin)
      )
      (node
        (ref "clone_79")
        (kind placement)
        (xy 79.0 0.0)
      )
    )
    (tree
      (name "clone_80")
      (anchor
        (origin)
      )
      (node
        (ref "clone_80")
        (kind placement)
        (xy 80.0 0.0)
      )
    )
    (tree
      (name "clone_81")
      (anchor
        (origin)
      )
      (node
        (ref "clone_81")
        (kind placement)
        (xy 81.0 0.0)
      )
    )
    (tree
      (name "clone_82")
      (anchor
        (origin)
      )
      (node
        (ref "clone_82")
        (kind placement)
        (xy 82.0 0.0)
      )
    )
    (tree
      (name "clone_83")
      (anchor
        (origin)
      )
      (node
        (ref "clone_83")
        (kind placement)
        (xy 83.0 0.0)
      )
    )
    (tree
      (name "clone_84")
      (anchor
        (origin)
      )
      (node
        (ref "clone_84")
        (kind placement)
        (xy 84.0 0.0)
      )
    )
    (tree
      (name "clone_85")
      (anchor
        (origin)
      )
      (node
        (ref "clone_85")
        (kind placement)
        (xy 85.0 0.0)
      )
    )
    (tree
      (name "clone_86")
      (anchor
        (origin)
      )
      (node
        (ref "clone_86")
        (kind placement)
        (xy 86.0 0.0)
      )
    )
    (tree
      (name "clone_87")
      (anchor
        (origin)
      )
      (node
        (ref "clone_87")
        (kind placement)
        (xy 87.0 0.0)
      )
    )
    (tree
      (name "clone_88")
      (anchor
        (origin)
      )
      (node
        (ref "clone_88")
        (kind placement)
        (xy 88.0 0.0)
      )
    )
    (tree
      (name "clone_89")
      (anchor
        (origin)
      )
      (node
        (ref "clone_89")
        (kind placement)
        (xy 89.0 0.0)
      )
    )
    (tree
      (name "clone_90")
      (anchor
        (origin)
      )
      (node
        (ref "clone_90")
        (kind placement)
        (xy 90.0 0.0)
      )
    )
    (tree
      (name "clone_91")
      (anchor
        (origin)
      )
      (node
        (ref "clone_91")
        (kind placement)
        (xy 91.0 0.0)
      )
    )
    (tree
      (name "clone_92")
      (anchor
        (origin)
      )
      (node
        (ref "clone_92")
        (kind placement)
        (xy 92.0 0.0)
      )
    )
    (tree
      (name "clone_93")
      (anchor
        (origin)
      )
      (node
        (ref "clone_93")
        (kind placement)
        (xy 93.0 0.0)
      )
    )
    (tree
      (name "clone_94")
      (anchor
        (origin)
      )
      (node
        (ref "clone_94")
        (kind placement)
        (xy 94.0 0.0)
      )
    )
    (tree
      (name "clone_95")
      (anchor
        (origin)
      )
      (node
        (ref "clone_95")
        (kind placement)
        (xy 95.0 0.0)
      )
    )
    (tree
      (name "clone_96")
      (anchor
        (origin)
      )
      (node
        (ref "clone_96")
        (kind placement)
        (xy 96.0 0.0)
      )
    )
    (tree
      (name "clone_97")
      (anchor
        (origin)
      )
      (node
        (ref "clone_97")
        (kind placement)
        (xy 97.0 0.0)
      )
    )
    (tree
      (name "clone_98")
      (anchor
        (origin)
      )
      (node
        (ref "clone_98")
        (kind placement)
        (xy 98.0 0.0)
      )
    )
    (tree
      (name "clone_99")
      (anchor
        (origin)
      )
      (node
        (ref "clone_99")
        (kind placement)
        (xy 99.0 0.0)
      )
    )
    (tree
      (name "clone_100")
      (anchor
        (origin)
      )
      (node
        (ref "clone_100")
        (kind placement)
        (xy 100.0 0.0)
      )
    )
    (tree
      (name "clone_101")
      (anchor
        (origin)
      )
      (node
        (ref "clone_101")
        (kind placement)
        (xy 101.0 0.0)
      )
    )
    (tree
      (name "clone_102")
      (anchor
        (origin)
      )
      (node
        (ref "clone_102")
        (kind placement)
        (xy 102.0 0.0)
      )
    )
    (tree
      (name "clone_103")
      (anchor
        (origin)
      )
      (node
        (ref "clone_103")
        (kind placement)
        (xy 103.0 0.0)
      )
    )
    (tree
      (name "clone_104")
      (anchor
        (origin)
      )
      (node
        (ref "clone_104")
        (kind placement)
        (xy 104.0 0.0)
      )
    )
    (tree
      (name "clone_105")
      (anchor
        (origin)
      )
      (node
        (ref "clone_105")
        (kind placement)
        (xy 105.0 0.0)
      )
    )
    (tree
      (name "clone_106")
      (anchor
        (origin)
      )
      (node
        (ref "clone_106")
        (kind placement)
        (xy 106.0 0.0)
      )
    )
    (tree
      (name "clone_107")
      (anchor
        (origin)
      )
      (node
        (ref "clone_107")
        (kind placement)
        (xy 107.0 0.0)
      )
    )
    (tree
      (name "clone_108")
      (anchor
        (origin)
      )
      (node
        (ref "clone_108")
        (kind placement)
        (xy 108.0 0.0)
      )
    )
    (tree
      (name "clone_109")
      (anchor
        (origin)
      )
      (node
        (ref "clone_109")
        (kind placement)
        (xy 109.0 0.0)
      )
    )
    (tree
      (name "clone_110")
      (anchor
        (origin)
      )
      (node
        (ref "clone_110")
        (kind placement)
        (xy 110.0 0.0)
      )
    )
    (tree
      (name "clone_111")
      (anchor
        (origin)
      )
      (node
        (ref "clone_111")
        (kind placement)
        (xy 111.0 0.0)
      )
    )
    (tree
      (name "clone_112")
      (anchor
        (origin)
      )
      (node
        (ref "clone_112")
        (kind placement)
        (xy 112.0 0.0)
      )
    )
    (tree
      (name "clone_113")
      (anchor
        (origin)
      )
      (node
        (ref "clone_113")
        (kind placement)
        (xy 113.0 0.0)
      )
    )
    (tree
      (name "clone_114")
      (anchor
        (origin)
      )
      (node
        (ref "clone_114")
        (kind placement)
        (xy 114.0 0.0)
      )
    )
    (tree
      (name "clone_115")
      (anchor
        (origin)
      )
      (node
        (ref "clone_115")
        (kind placement)
        (xy 115.0 0.0)
      )
    )
    (tree
      (name "clone_116")
      (anchor
        (origin)
      )
      (node
        (ref "clone_116")
        (kind placement)
        (xy 116.0 0.0)
      )
    )
    (tree
      (name "clone_117")
      (anchor
        (origin)
      )
      (node
        (ref "clone_117")
        (kind placement)
        (xy 117.0 0.0)
      )
    )
    (tree
      (name "clone_118")
      (anchor
        (origin)
      )
      (node
        (ref "clone_118")
        (kind placement)
        (xy 118.0 0.0)
      )
    )
    (tree
      (name "clone_119")
      (anchor
        (origin)
      )
      (node
        (ref "clone_119")
        (kind placement)
        (xy 119.0 0.0)
      )
    )
    (tree
      (name "clone_120")
      (anchor
        (origin)
      )
      (node
        (ref "clone_120")
        (kind placement)
        (xy 120.0 0.0)
      )
    )
    (tree
      (name "clone_121")
      (anchor
        (origin)
      )
      (node
        (ref "clone_121")
        (kind placement)
        (xy 121.0 0.0)
      )
    )
    (tree
      (name "clone_122")
      (anchor
        (origin)
      )
      (node
        (ref "clone_122")
        (kind placement)
        (xy 122.0 0.0)
      )
    )
    (tree
      (name "clone_123")
      (anchor
        (origin)
      )
      (node
        (ref "clone_123")
        (kind placement)
        (xy 123.0 0.0)
      )
    )
    (tree
      (name "clone_124")
      (anchor
        (origin)
      )
      (node
        (ref "clone_124")
        (kind placement)
        (xy 124.0 0.0)
      )
    )
    (tree
      (name "clone_125")
      (anchor
        (origin)
      )
      (node
        (ref "clone_125")
        (kind placement)
        (xy 125.0 0.0)
      )
    )
    (tree
      (name "clone_126")
      (anchor
        (origin)
      )
      (node
        (ref "clone_126")
        (kind placement)
        (xy 126.0 0.0)
      )
    )
    (tree
      (name "clone_127")
      (anchor
        (origin)
      )
      (node
        (ref "clone_127")
        (kind placement)
        (xy 127.0 0.0)
      )
    )
    (tree
      (name "clone_128")
      (anchor
        (origin)
      )
      (node
        (ref "clone_128")
        (kind placement)
        (xy 128.0 0.0)
      )
    )
    (tree
      (name "clone_129")
      (anchor
        (origin)
      )
      (node
        (ref "clone_129")
        (kind placement)
        (xy 129.0 0.0)
      )
    )
    (tree
      (name "clone_130")
      (anchor
        (origin)
      )
      (node
        (ref "clone_130")
        (kind placement)
        (xy 130.0 0.0)
      )
    )
    (tree
      (name "clone_131")
      (anchor
        (origin)
      )
      (node
        (ref "clone_131")
        (kind placement)
        (xy 131.0 0.0)
      )
    )
    (tree
      (name "clone_132")
      (anchor
        (origin)
      )
      (node
        (ref "clone_132")
        (kind placement)
        (xy 132.0 0.0)
      )
    )
    (tree
      (name "clone_133")
      (anchor
        (origin)
      )
      (node
        (ref "clone_133")
        (kind placement)
        (xy 133.0 0.0)
      )
    )
    (tree
      (name "clone_134")
      (anchor
        (origin)
      )
      (node
        (ref "clone_134")
        (kind placement)
        (xy 134.0 0.0)
      )
    )
    (tree
      (name "clone_135")
      (anchor
        (origin)
      )
      (node
        (ref "clone_135")
        (kind placement)
        (xy 135.0 0.0)
      )
    )
    (tree
      (name "clone_136")
      (anchor
        (origin)
      )
      (node
        (ref "clone_136")
        (kind placement)
        (xy 136.0 0.0)
      )
    )
    (tree
      (name "clone_137")
      (anchor
        (origin)
      )
      (node
        (ref "clone_137")
        (kind placement)
        (xy 137.0 0.0)
      )
    )
    (tree
      (name "clone_138")
      (anchor
        (origin)
      )
      (node
        (ref "clone_138")
        (kind placement)
        (xy 138.0 0.0)
      )
    )
    (tree
      (name "clone_139")
      (anchor
        (origin)
      )
      (node
        (ref "clone_139")
        (kind placement)
        (xy 139.0 0.0)
      )
    )
    (tree
      (name "clone_140")
      (anchor
        (origin)
      )
      (node
        (ref "clone_140")
        (kind placement)
        (xy 140.0 0.0)
      )
    )
    (tree
      (name "clone_141")
      (anchor
        (origin)
      )
      (node
        (ref "clone_141")
        (kind placement)
        (xy 141.0 0.0)
      )
    )
    (tree
      (name "clone_142")
      (anchor
        (origin)
      )
      (node
        (ref "clone_142")
        (kind placement)
        (xy 142.0 0.0)
      )
    )
    (tree
      (name "clone_143")
      (anchor
        (origin)
      )
      (node
        (ref "clone_143")
        (kind placement)
        (xy 143.0 0.0)
      )
    )
    (tree
      (name "clone_144")
      (anchor
        (origin)
      )
      (node
        (ref "clone_144")
        (kind placement)
        (xy 144.0 0.0)
      )
    )
    (tree
      (name "clone_145")
      (anchor
        (origin)
      )
      (node
        (ref "clone_145")
        (kind placement)
        (xy 145.0 0.0)
      )
    )
    (tree
      (name "clone_146")
      (anchor
        (origin)
      )
      (node
        (ref "clone_146")
        (kind placement)
        (xy 146.0 0.0)
      )
    )
    (tree
      (name "clone_147")
      (anchor
        (origin)
      )
      (node
        (ref "clone_147")
        (kind placement)
        (xy 147.0 0.0)
      )
    )
    (tree
      (name "clone_148")
      (anchor
        (origin)
      )
      (node
        (ref "clone_148")
        (kind placement)
        (xy 148.0 0.0)
      )
    )
    (tree
      (name "clone_149")
      (anchor
        (origin)
      )
      (node
        (ref "clone_149")
        (kind placement)
        (xy 149.0 0.0)
      )
    )
    (tree
      (name "clone_150")
      (anchor
        (origin)
      )
      (node
        (ref "clone_150")
        (kind placement)
        (xy 150.0 0.0)
      )
    )
    (tree
      (name "clone_151")
      (anchor
        (origin)
      )
      (node
        (ref "clone_151")
        (kind placement)
        (xy 151.0 0.0)
      )
    )
    (tree
      (name "clone_152")
      (anchor
        (origin)
      )
      (node
        (ref "clone_152")
        (kind placement)
        (xy 152.0 0.0)
      )
    )
    (tree
      (name "clone_153")
      (anchor
        (origin)
      )
      (node
        (ref "clone_153")
        (kind placement)
        (xy 153.0 0.0)
      )
    )
    (tree
      (name "clone_154")
      (anchor
        (origin)
      )
      (node
        (ref "clone_154")
        (kind placement)
        (xy 154.0 0.0)
      )
    )
    (tree
      (name "clone_155")
      (anchor
        (origin)
      )
      (node
        (ref "clone_155")
        (kind placement)
        (xy 155.0 0.0)
      )
    )
    (tree
      (name "clone_156")
      (anchor
        (origin)
      )
      (node
        (ref "clone_156")
        (kind placement)
        (xy 156.0 0.0)
      )
    )
    (tree
      (name "clone_157")
      (anchor
        (origin)
      )
      (node
        (ref "clone_157")
        (kind placement)
        (xy 157.0 0.0)
      )
    )
    (tree
      (name "clone_158")
      (anchor
        (origin)
      )
      (node
        (ref "clone_158")
        (kind placement)
        (xy 158.0 0.0)
      )
    )
    (tree
      (name "clone_159")
      (anchor
        (origin)
      )
      (node
        (ref "clone_159")
        (kind placement)
        (xy 159.0 0.0)
      )
    )
    (tree
      (name "clone_160")
      (anchor
        (origin)
      )
      (node
        (ref "clone_160")
        (kind placement)
        (xy 160.0 0.0)
      )
    )
    (tree
      (name "clone_161")
      (anchor
        (origin)
      )
      (node
        (ref "clone_161")
        (kind placement)
        (xy 161.0 0.0)
      )
    )
    (tree
      (name "clone_162")
      (anchor
        (origin)
      )
      (node
        (ref "clone_162")
        (kind placement)
        (xy 162.0 0.0)
      )
    )
    (tree
      (name "clone_163")
      (anchor
        (origin)
      )
      (node
        (ref "clone_163")
        (kind placement)
        (xy 163.0 0.0)
      )
    )
    (tree
      (name "clone_164")
      (anchor
        (origin)
      )
      (node
        (ref "clone_164")
        (kind placement)
        (xy 164.0 0.0)
      )
    )
    (tree
      (name "clone_165")
      (anchor
        (origin)
      )
      (node
        (ref "clone_165")
        (kind placement)
        (xy 165.0 0.0)
      )
    )
    (tree
      (name "clone_166")
      (anchor
        (origin)
      )
      (node
        (ref "clone_166")
        (kind placement)
        (xy 166.0 0.0)
      )
    )
    (tree
      (name "clone_167")
      (anchor
        (origin)
      )
      (node
        (ref "clone_167")
        (kind placement)
        (xy 167.0 0.0)
      )
    )
    (tree
      (name "clone_168")
      (anchor
        (origin)
      )
      (node
        (ref "clone_168")
        (kind placement)
        (xy 168.0 0.0)
      )
    )
    (tree
      (name "clone_169")
      (anchor
        (origin)
      )
      (node
        (ref "clone_169")
        (kind placement)
        (xy 169.0 0.0)
      )
    )
    (tree
      (name "clone_170")
      (anchor
        (origin)
      )
      (node
        (ref "clone_170")
        (kind placement)
        (xy 170.0 0.0)
      )
    )
    (tree
      (name "clone_171")
      (anchor
        (origin)
      )
      (node
        (ref "clone_171")
        (kind placement)
        (xy 171.0 0.0)
      )
    )
    (tree
      (name "clone_172")
      (anchor
        (origin)
      )
      (node
        (ref "clone_172")
        (kind placement)
        (xy 172.0 0.0)
      )
    )
    (tree
      (name "clone_173")
      (anchor
        (origin)
      )
      (node
        (ref "clone_173")
        (kind placement)
        (xy 173.0 0.0)
      )
    )
    (tree
      (name "clone_174")
      (anchor
        (origin)
      )
      (node
        (ref "clone_174")
        (kind placement)
        (xy 174.0 0.0)
      )
    )
    (tree
      (name "clone_175")
      (anchor
        (origin)
      )
      (node
        (ref "clone_175")
        (kind placement)
        (xy 175.0 0.0)
      )
    )
    (tree
      (name "clone_176")
      (anchor
        (origin)
      )
      (node
        (ref "clone_176")
        (kind placement)
        (xy 176.0 0.0)
      )
    )
    (tree
      (name "clone_177")
      (anchor
        (origin)
      )
      (node
        (ref "clone_177")
        (kind placement)
        (xy 177.0 0.0)
      )
    )
    (tree
      (name "clone_178")
      (anchor
        (origin)
      )
      (node
        (ref "clone_178")
        (kind placement)
        (xy 178.0 0.0)
      )
    )
    (tree
      (name "clone_179")
      (anchor
        (origin)
      )
      (node
        (ref "clone_179")
        (kind placement)
        (xy 179.0 0.0)
      )
    )
    (tree
      (name "clone_180")
      (anchor
        (origin)
      )
      (node
        (ref "clone_180")
        (kind placement)
        (xy 180.0 0.0)
      )
    )
    (tree
      (name "clone_181")
      (anchor
        (origin)
      )
      (node
        (ref "clone_181")
        (kind placement)
        (xy 181.0 0.0)
      )
    )
    (tree
      (name "clone_182")
      (anchor
        (origin)
      )
      (node
        (ref "clone_182")
        (kind placement)
        (xy 182.0 0.0)
      )
    )
    (tree
      (name "clone_183")
      (anchor
        (origin)
      )
      (node
        (ref "clone_183")
        (kind placement)
        (xy 183.0 0.0)
      )
    )
    (tree
      (name "clone_184")
      (anchor
        (origin)
      )
      (node
        (ref "clone_184")
        (kind placement)
        (xy 184.0 0.0)
      )
    )
    (tree
      (name "clone_185")
      (anchor
        (origin)
      )
      (node
        (ref "clone_185")
        (kind placement)
        (xy 185.0 0.0)
      )
    )
    (tree
      (name "clone_186")
      (anchor
        (origin)
      )
      (node
        (ref "clone_186")
        (kind placement)
        (xy 186.0 0.0)
      )
    )
    (tree
      (name "clone_187")
      (anchor
        (origin)
      )
      (node
        (ref "clone_187")
        (kind placement)
        (xy 187.0 0.0)
      )
    )
    (tree
      (name "clone_188")
      (anchor
        (origin)
      )
      (node
        (ref "clone_188")
        (kind placement)
        (xy 188.0 0.0)
      )
    )
    (tree
      (name "clone_189")
      (anchor
        (origin)
      )
      (node
        (ref "clone_189")
        (kind placement)
        (xy 189.0 0.0)
      )
    )
    (tree
      (name "clone_190")
      (anchor
        (origin)
      )
      (node
        (ref "clone_190")
        (kind placement)
        (xy 190.0 0.0)
      )
    )
    (tree
      (name "clone_191")
      (anchor
        (origin)
      )
      (node
        (ref "clone_191")
        (kind placement)
        (xy 191.0 0.0)
      )
    )
    (tree
      (name "clone_192")
      (anchor
        (origin)
      )
      (node
        (ref "clone_192")
        (kind placement)
        (xy 192.0 0.0)
      )
    )
    (tree
      (name "clone_193")
      (anchor
        (origin)
      )
      (node
        (ref "clone_193")
        (kind placement)
        (xy 193.0 0.0)
      )
    )
    (tree
      (name "clone_194")
      (anchor
        (origin)
      )
      (node
        (ref "clone_194")
        (kind placement)
        (xy 194.0 0.0)
      )
    )
    (tree
      (name "clone_195")
      (anchor
        (origin)
      )
      (node
        (ref "clone_195")
        (kind placement)
        (xy 195.0 0.0)
      )
    )
    (tree
      (name "clone_196")
      (anchor
        (origin)
      )
      (node
        (ref "clone_196")
        (kind placement)
        (xy 196.0 0.0)
      )
    )
    (tree
      (name "clone_197")
      (anchor
        (origin)
      )
      (node
        (ref "clone_197")
        (kind placement)
        (xy 197.0 0.0)
      )
    )
    (tree
      (name "clone_198")
      (anchor
        (origin)
      )
      (node
        (ref "clone_198")
        (kind placement)
        (xy 198.0 0.0)
      )
    )
    (tree
      (name "clone_199")
      (anchor
        (origin)
      )
      (node
        (ref "clone_199")
        (kind placement)
        (xy 199.0 0.0)
      )
    )
    (tree
      (name "clone_200")
      (anchor
        (origin)
      )
      (node
        (ref "clone_200")
        (kind placement)
        (xy 200.0 0.0)
      )
    )
    (tree
      (name "clone_201")
      (anchor
        (origin)
      )
      (node
        (ref "clone_201")
        (kind placement)
        (xy 201.0 0.0)
      )
    )
    (tree
      (name "clone_202")
      (anchor
        (origin)
      )
      (node
        (ref "clone_202")
        (kind placement)
        (xy 202.0 0.0)
      )
    )
    (tree
      (name "clone_203")
      (anchor
        (origin)
      )
      (node
        (ref "clone_203")
        (kind placement)
        (xy 203.0 0.0)
      )
    )
    (tree
      (name "clone_204")
      (anchor
        (origin)
      )
      (node
        (ref "clone_204")
        (kind placement)
        (xy 204.0 0.0)
      )
    )
    (tree
      (name "clone_205")
      (anchor
        (origin)
      )
      (node
        (ref "clone_205")
        (kind placement)
        (xy 205.0 0.0)
      )
    )
    (tree
      (name "clone_206")
      (anchor
        (origin)
      )
      (node
        (ref "clone_206")
        (kind placement)
        (xy 206.0 0.0)
      )
    )
    (tree
      (name "clone_207")
      (anchor
        (origin)
      )
      (node
        (ref "clone_207")
        (kind placement)
        (xy 207.0 0.0)
      )
    )
    (tree
      (name "clone_208")
      (anchor
        (origin)
      )
      (node
        (ref "clone_208")
        (kind placement)
        (xy 208.0 0.0)
      )
    )
    (tree
      (name "clone_209")
      (anchor
        (origin)
      )
      (node
        (ref "clone_209")
        (kind placement)
        (xy 209.0 0.0)
      )
    )
    (tree
      (name "clone_210")
      (anchor
        (origin)
      )
      (node
        (ref "clone_210")
        (kind placement)
        (xy 210.0 0.0)
      )
    )
    (tree
      (name "clone_211")
      (anchor
        (origin)
      )
      (node
        (ref "clone_211")
        (kind placement)
        (xy 211.0 0.0)
      )
    )
    (tree
      (name "clone_212")
      (anchor
        (origin)
      )
      (node
        (ref "clone_212")
        (kind placement)
        (xy 212.0 0.0)
      )
    )
    (tree
      (name "clone_213")
      (anchor
        (origin)
      )
      (node
        (ref "clone_213")
        (kind placement)
        (xy 213.0 0.0)
      )
    )
    (tree
      (name "clone_214")
      (anchor
        (origin)
      )
      (node
        (ref "clone_214")
        (kind placement)
        (xy 214.0 0.0)
      )
    )
    (tree
      (name "clone_215")
      (anchor
        (origin)
      )
      (node
        (ref "clone_215")
        (kind placement)
        (xy 215.0 0.0)
      )
    )
    (tree
      (name "clone_216")
      (anchor
        (origin)
      )
      (node
        (ref "clone_216")
        (kind placement)
        (xy 216.0 0.0)
      )
    )
    (tree
      (name "clone_217")
      (anchor
        (origin)
      )
      (node
        (ref "clone_217")
        (kind placement)
        (xy 217.0 0.0)
      )
    )
    (tree
      (name "clone_218")
      (anchor
        (origin)
      )
      (node
        (ref "clone_218")
        (kind placement)
        (xy 218.0 0.0)
      )
    )
    (tree
      (name "clone_219")
      (anchor
        (origin)
      )
      (node
        (ref "clone_219")
        (kind placement)
        (xy 219.0 0.0)
      )
    )
    (tree
      (name "clone_220")
      (anchor
        (origin)
      )
      (node
        (ref "clone_220")
        (kind placement)
        (xy 220.0 0.0)
      )
    )
    (tree
      (name "clone_221")
      (anchor
        (origin)
      )
      (node
        (ref "clone_221")
        (kind placement)
        (xy 221.0 0.0)
      )
    )
    (tree
      (name "clone_222")
      (anchor
        (origin)
      )
      (node
        (ref "clone_222")
        (kind placement)
        (xy 222.0 0.0)
      )
    )
    (tree
      (name "clone_223")
      (anchor
        (origin)
      )
      (node
        (ref "clone_223")
        (kind placement)
        (xy 223.0 0.0)
      )
    )
    (tree
      (name "clone_224")
      (anchor
        (origin)
      )
      (node
        (ref "clone_224")
        (kind placement)
        (xy 224.0 0.0)
      )
    )
    (tree
      (name "clone_225")
      (anchor
        (origin)
      )
      (node
        (ref "clone_225")
        (kind placement)
        (xy 225.0 0.0)
      )
    )
    (tree
      (name "clone_226")
      (anchor
        (origin)
      )
      (node
        (ref "clone_226")
        (kind placement)
        (xy 226.0 0.0)
      )
    )
    (tree
      (name "clone_227")
      (anchor
        (origin)
      )
      (node
        (ref "clone_227")
        (kind placement)
        (xy 227.0 0.0)
      )
    )
    (tree
      (name "clone_228")
      (anchor
        (origin)
      )
      (node
        (ref "clone_228")
        (kind placement)
        (xy 228.0 0.0)
      )
    )
    (tree
      (name "clone_229")
      (anchor
        (origin)
      )
      (node
        (ref "clone_229")
        (kind placement)
        (xy 229.0 0.0)
      )
    )
    (tree
      (name "clone_230")
      (anchor
        (origin)
      )
      (node
        (ref "clone_230")
        (kind placement)
        (xy 230.0 0.0)
      )
    )
    (tree
      (name "clone_231")
      (anchor
        (origin)
      )
      (node
        (ref "clone_231")
        (kind placement)
        (xy 231.0 0.0)
      )
    )
    (tree
      (name "clone_232")
      (anchor
        (origin)
      )
      (node
        (ref "clone_232")
        (kind placement)
        (xy 232.0 0.0)
      )
    )
    (tree
      (name "clone_233")
      (anchor
        (origin)
      )
      (node
        (ref "clone_233")
        (kind placement)
        (xy 233.0 0.0)
      )
    )
    (tree
      (name "clone_234")
      (anchor
        (origin)
      )
      (node
        (ref "clone_234")
        (kind placement)
        (xy 234.0 0.0)
      )
    )
    (tree
      (name "clone_235")
      (anchor
        (origin)
      )
      (node
        (ref "clone_235")
        (kind placement)
        (xy 235.0 0.0)
      )
    )
    (tree
      (name "clone_236")
      (anchor
        (origin)
      )
      (node
        (ref "clone_236")
        (kind placement)
        (xy 236.0 0.0)
      )
    )
    (tree
      (name "clone_237")
      (anchor
        (origin)
      )
      (node
        (ref "clone_237")
        (kind placement)
        (xy 237.0 0.0)
      )
    )
    (tree
      (name "clone_238")
      (anchor
        (origin)
      )
      (node
        (ref "clone_238")
        (kind placement)
        (xy 238.0 0.0)
      )
    )
    (tree
      (name "clone_239")
      (anchor
        (origin)
      )
      (node
        (ref "clone_239")
        (kind placement)
        (xy 239.0 0.0)
      )
    )
    (tree
      (name "clone_240")
      (anchor
        (origin)
      )
      (node
        (ref "clone_240")
        (kind placement)
        (xy 240.0 0.0)
      )
    )
    (tree
      (name "clone_241")
      (anchor
        (origin)
      )
      (node
        (ref "clone_241")
        (kind placement)
        (xy 241.0 0.0)
      )
    )
    (tree
      (name "clone_242")
      (anchor
        (origin)
      )
      (node
        (ref "clone_242")
        (kind placement)
        (xy 242.0 0.0)
      )
    )
    (tree
      (name "clone_243")
      (anchor
        (origin)
      )
      (node
        (ref "clone_243")
        (kind placement)
        (xy 243.0 0.0)
      )
    )
    (tree
      (name "clone_244")
      (anchor
        (origin)
      )
      (node
        (ref "clone_244")
        (kind placement)
        (xy 244.0 0.0)
      )
    )
    (tree
      (name "clone_245")
      (anchor
        (origin)
      )
      (node
        (ref "clone_245")
        (kind placement)
        (xy 245.0 0.0)
      )
    )
    (tree
      (name "clone_246")
      (anchor
        (origin)
      )
      (node
        (ref "clone_246")
        (kind placement)
        (xy 246.0 0.0)
      )
    )
    (tree
      (name "clone_247")
      (anchor
        (origin)
      )
      (node
        (ref "clone_247")
        (kind placement)
        (xy 247.0 0.0)
      )
    )
    (tree
      (name "clone_248")
      (anchor
        (origin)
      )
      (node
        (ref "clone_248")
        (kind placement)
        (xy 248.0 0.0)
      )
    )
    (tree
      (name "clone_249")
      (anchor
        (origin)
      )
      (node
        (ref "clone_249")
        (kind placement)
        (xy 249.0 0.0)
      )
    )
    (tree
      (name "clone_250")
      (anchor
        (origin)
      )
      (node
        (ref "clone_250")
        (kind placement)
        (xy 250.0 0.0)
      )
    )
    (tree
      (name "clone_251")
      (anchor
        (origin)
      )
      (node
        (ref "clone_251")
        (kind placement)
        (xy 251.0 0.0)
      )
    )
    (tree
      (name "clone_252")
      (anchor
        (origin)
      )
      (node
        (ref "clone_252")
        (kind placement)
        (xy 252.0 0.0)
      )
    )
    (tree
      (name "clone_253")
      (anchor
        (origin)
      )
      (node
        (ref "clone_253")
        (kind placement)
        (xy 253.0 0.0)
      )
    )
    (tree
      (name "clone_254")
      (anchor
        (origin)
      )
      (node
        (ref "clone_254")
        (kind placement)
        (xy 254.0 0.0)
      )
    )
    (tree
      (name "clone_255")
      (anchor
        (origin)
      )
      (node
        (ref "clone_255")
        (kind placement)
        (xy 255.0 0.0)
      )
    )
    (tree
      (name "clone_256")
      (anchor
        (origin)
      )
      (node
        (ref "clone_256")
        (kind placement)
        (xy 256.0 0.0)
      )
    )
    (tree
      (name "clone_257")
      (anchor
        (origin)
      )
      (node
        (ref "clone_257")
        (kind placement)
        (xy 257.0 0.0)
      )
    )
    (tree
      (name "clone_258")
      (anchor
        (origin)
      )
      (node
        (ref "clone_258")
        (kind placement)
        (xy 258.0 0.0)
      )
    )
    (tree
      (name "clone_259")
      (anchor
        (origin)
      )
      (node
        (ref "clone_259")
        (kind placement)
        (xy 259.0 0.0)
      )
    )
    (tree
      (name "clone_260")
      (anchor
        (origin)
      )
      (node
        (ref "clone_260")
        (kind placement)
        (xy 260.0 0.0)
      )
    )
    (tree
      (name "clone_261")
      (anchor
        (origin)
      )
      (node
        (ref "clone_261")
        (kind placement)
        (xy 261.0 0.0)
      )
    )
    (tree
      (name "clone_262")
      (anchor
        (origin)
      )
      (node
        (ref "clone_262")
        (kind placement)
        (xy 262.0 0.0)
      )
    )
    (tree
      (name "clone_263")
      (anchor
        (origin)
      )
      (node
        (ref "clone_263")
        (kind placement)
        (xy 263.0 0.0)
      )
    )
    (tree
      (name "clone_264")
      (anchor
        (origin)
      )
      (node
        (ref "clone_264")
        (kind placement)
        (xy 264.0 0.0)
      )
    )
    (tree
      (name "clone_265")
      (anchor
        (origin)
      )
      (node
        (ref "clone_265")
        (kind placement)
        (xy 265.0 0.0)
      )
    )
    (tree
      (name "clone_266")
      (anchor
        (origin)
      )
      (node
        (ref "clone_266")
        (kind placement)
        (xy 266.0 0.0)
      )
    )
    (tree
      (name "clone_267")
      (anchor
        (origin)
      )
      (node
        (ref "clone_267")
        (kind placement)
        (xy 267.0 0.0)
      )
    )
    (tree
      (name "clone_268")
      (anchor
        (origin)
      )
      (node
        (ref "clone_268")
        (kind placement)
        (xy 268.0 0.0)
      )
    )
    (tree
      (name "clone_269")
      (anchor
        (origin)
      )
      (node
        (ref "clone_269")
        (kind placement)
        (xy 269.0 0.0)
      )
    )
    (tree
      (name "clone_270")
      (anchor
        (origin)
      )
      (node
        (ref "clone_270")
        (kind placement)
        (xy 270.0 0.0)
      )
    )
    (tree
      (name "clone_271")
      (anchor
        (origin)
      )
      (node
        (ref "clone_271")
        (kind placement)
        (xy 271.0 0.0)
      )
    )
    (tree
      (name "clone_272")
      (anchor
        (origin)
      )
      (node
        (ref "clone_272")
        (kind placement)
        (xy 272.0 0.0)
      )
    )
    (tree
      (name "clone_273")
      (anchor
        (origin)
      )
      (node
        (ref "clone_273")
        (kind placement)
        (xy 273.0 0.0)
      )
    )
    (tree
      (name "clone_274")
      (anchor
        (origin)
      )
      (node
        (ref "clone_274")
        (kind placement)
        (xy 274.0 0.0)
      )
    )
    (tree
      (name "clone_275")
      (anchor
        (origin)
      )
      (node
        (ref "clone_275")
        (kind placement)
        (xy 275.0 0.0)
      )
    )
    (tree
      (name "clone_276")
      (anchor
        (origin)
      )
      (node
        (ref "clone_276")
        (kind placement)
        (xy 276.0 0.0)
      )
    )
    (tree
      (name "clone_277")
      (anchor
        (origin)
      )
      (node
        (ref "clone_277")
        (kind placement)
        (xy 277.0 0.0)
      )
    )
    (tree
      (name "clone_278")
      (anchor
        (origin)
      )
      (node
        (ref "clone_278")
        (kind placement)
        (xy 278.0 0.0)
      )
    )
    (tree
      (name "clone_279")
      (anchor
        (origin)
      )
      (node
        (ref "clone_279")
        (kind placement)
        (xy 279.0 0.0)
      )
    )
    (tree
      (name "clone_280")
      (anchor
        (origin)
      )
      (node
        (ref "clone_280")
        (kind placement)
        (xy 280.0 0.0)
      )
    )
    (tree
      (name "clone_281")
      (anchor
        (origin)
      )
      (node
        (ref "clone_281")
        (kind placement)
        (xy 281.0 0.0)
      )
    )
    (tree
      (name "clone_282")
      (anchor
        (origin)
      )
      (node
        (ref "clone_282")
        (kind placement)
        (xy 282.0 0.0)
      )
    )
    (tree
      (name "clone_283")
      (anchor
        (origin)
      )
      (node
        (ref "clone_283")
        (kind placement)
        (xy 283.0 0.0)
      )
    )
    (tree
      (name "clone_284")
      (anchor
        (origin)
      )
      (node
        (ref "clone_284")
        (kind placement)
        (xy 284.0 0.0)
      )
    )
    (tree
      (name "clone_285")
      (anchor
        (origin)
      )
      (node
        (ref "clone_285")
        (kind placement)
        (xy 285.0 0.0)
      )
    )
    (tree
      (name "clone_286")
      (anchor
        (origin)
      )
      (node
        (ref "clone_286")
        (kind placement)
        (xy 286.0 0.0)
      )
    )
    (tree
      (name "clone_287")
      (anchor
        (origin)
      )
      (node
        (ref "clone_287")
        (kind placement)
        (xy 287.0 0.0)
      )
    )
    (tree
      (name "clone_288")
      (anchor
        (origin)
      )
      (node
        (ref "clone_288")
        (kind placement)
        (xy 288.0 0.0)
      )
    )
    (tree
      (name "clone_289")
      (anchor
        (origin)
      )
      (node
        (ref "clone_289")
        (kind placement)
        (xy 289.0 0.0)
      )
    )
    (tree
      (name "clone_290")
      (anchor
        (origin)
      )
      (node
        (ref "clone_290")
        (kind placement)
        (xy 290.0 0.0)
      )
    )
    (tree
      (name "clone_291")
      (anchor
        (origin)
      )
      (node
        (ref "clone_291")
        (kind placement)
        (xy 291.0 0.0)
      )
    )
    (tree
      (name "clone_292")
      (anchor
        (origin)
      )
      (node
        (ref "clone_292")
        (kind placement)
        (xy 292.0 0.0)
      )
    )
    (tree
      (name "clone_293")
      (anchor
        (origin)
      )
      (node
        (ref "clone_293")
        (kind placement)
        (xy 293.0 0.0)
      )
    )
    (tree
      (name "clone_294")
      (anchor
        (origin)
      )
      (node
        (ref "clone_294")
        (kind placement)
        (xy 294.0 0.0)
      )
    )
    (tree
      (name "clone_295")
      (anchor
        (origin)
      )
      (node
        (ref "clone_295")
        (kind placement)
        (xy 295.0 0.0)
      )
    )
    (tree
      (name "clone_296")
      (anchor
        (origin)
      )
      (node
        (ref "clone_296")
        (kind placement)
        (xy 296.0 0.0)
      )
    )
    (tree
      (name "clone_297")
      (anchor
        (origin)
      )
      (node
        (ref "clone_297")
        (kind placement)
        (xy 297.0 0.0)
      )
    )
    (tree
      (name "clone_298")
      (anchor
        (origin)
      )
      (node
        (ref "clone_298")
        (kind placement)
        (xy 298.0 0.0)
      )
    )
    (tree
      (name "clone_299")
      (anchor
        (origin)
      )
      (node
        (ref "clone_299")
        (kind placement)
        (xy 299.0 0.0)
      )
    )
  )
)
