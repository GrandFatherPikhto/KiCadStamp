(kicadstamp-config
  (schematic_dir "../../../../KiCad/Test/Test-IPC-Nightly")
  (schematic_files "../../../../KiCad/Test/Test-IPC-Nightly/Test-IPC-Nightly.kicad_sch")
  (entities)
  (trees)
  (clone_placements)
)
